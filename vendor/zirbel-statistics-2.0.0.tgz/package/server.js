// packages/statistics/src/server.ts
import { randomUUID } from "node:crypto";
import { mkdir, open, rename, unlink } from "node:fs/promises";
import { dirname, join } from "node:path";
import { GameStatistics, readStatistics } from "@zirbel/core/statistics";
var MAX_BYTES = 16 * 1024 * 1024;
function missing(error) {
  return error instanceof Error && "code" in error && error.code === "ENOENT";
}
async function readBounded(file) {
  const handle = await open(file, "r");
  try {
    const stat = await handle.stat();
    if (!stat.isFile() || stat.size > MAX_BYTES) throw new Error("Statistics file exceeds its bound");
    const buffer = Buffer.alloc(Math.min(MAX_BYTES + 1, stat.size + 1));
    let length = 0;
    while (length < buffer.length) {
      const { bytesRead } = await handle.read(buffer, length, buffer.length - length, null);
      if (!bytesRead) break;
      length += bytesRead;
    }
    if (length > stat.size || length > MAX_BYTES) throw new Error("Statistics file changed during read");
    return JSON.parse(buffer.subarray(0, length).toString("utf8"));
  } finally {
    await handle.close();
  }
}
async function persist(file, data) {
  const temporary = `${file}.${randomUUID()}.tmp`;
  let renamed = false;
  try {
    const handle = await open(temporary, "wx", 384);
    try {
      await handle.writeFile(data, "utf8");
      await handle.sync();
    } finally {
      await handle.close();
    }
    await rename(temporary, file);
    renamed = true;
    if (process.platform !== "win32") {
      const directory = await open(dirname(file), "r");
      try {
        await directory.sync();
      } finally {
        await directory.close();
      }
    }
  } finally {
    if (!renamed)
      await unlink(temporary).catch((error) => {
        if (!missing(error)) throw error;
      });
  }
}
async function openStatistics(o) {
  const model = new GameStatistics(o.instance);
  const interval = o.intervalMs ?? 15e3;
  if (!Number.isSafeInteger(interval) || interval < 1e3 || interval > 6e4)
    throw new Error("Invalid statistics interval");
  const now = o.now ?? Date.now;
  model.snapshot(now());
  const file = join(o.directory, `statistics-${o.instance}.json`);
  await mkdir(o.directory, { recursive: true, mode: 448 });
  try {
    const snapshot = readStatistics(await readBounded(file));
    if (!snapshot) throw new Error("Invalid stored statistics");
    model.restore(snapshot);
  } catch (error) {
    if (!missing(error)) throw error;
  }
  let closed = false;
  let dirty = false;
  let dropped = 0;
  let writes = Promise.resolve();
  let closing = null;
  const flush = () => {
    writes = writes.catch(() => {
    }).then(async () => {
      if (!dirty) return;
      dirty = false;
      try {
        const data = JSON.stringify(model.snapshot(now()));
        if (Buffer.byteLength(data) > MAX_BYTES) throw new Error("Statistics snapshot exceeds its bound");
        await persist(file, data);
      } catch (error) {
        dirty = true;
        throw error;
      }
    });
    return writes;
  };
  const timer = setInterval(() => {
    try {
      model.sample(now());
      dirty = true;
      void flush().catch(o.failed);
    } catch (error) {
      o.failed(error);
    }
  }, interval);
  timer.unref();
  return {
    report(report) {
      if (!closed) {
        if (model.report(report)) dirty = true;
        else dropped++;
      }
    },
    closed(room) {
      if (!closed) {
        model.closed(room);
        dirty = true;
      }
    },
    snapshot() {
      return model.snapshot(now());
    },
    flush,
    get dropped() {
      return dropped;
    },
    http(req, res) {
      const path = (req.url ?? "").split("?")[0];
      const data = path === "/mp/stats" || path === "/stats/v1";
      const asset = path === "/stats" || path === "/stats/" ? "html" : path === "/stats/client.js" ? "js" : path === "/stats/style.css" ? "css" : null;
      if (!data && !(asset && o.view)) return false;
      const headers = {
        "access-control-allow-origin": "*",
        "cache-control": data ? "public, max-age=10" : "public, max-age=60",
        "x-content-type-options": "nosniff"
      };
      if (req.method !== "GET" && req.method !== "HEAD") {
        res.writeHead(405, { ...headers, allow: "GET, HEAD" });
        res.end();
        return true;
      }
      const type = data ? "application/json" : asset === "js" ? "text/javascript" : asset === "css" ? "text/css" : "text/html";
      let body;
      try {
        body = data ? JSON.stringify(model.snapshot(now())) : o.view[asset];
      } catch (error) {
        o.failed(error);
        res.writeHead(503, { ...headers, "cache-control": "no-store" });
        res.end();
        return true;
      }
      res.writeHead(200, {
        ...headers,
        "content-type": type + "; charset=utf-8",
        "content-length": Buffer.byteLength(body)
      });
      res.end(req.method === "HEAD" ? void 0 : body);
      return true;
    },
    close() {
      if (closing) return closing;
      closed = true;
      clearInterval(timer);
      closing = flush();
      return closing;
    }
  };
}
export {
  openStatistics
};
