export declare const statisticsView: { readonly html: string; readonly js: string; readonly css: string };
