import type { IncomingMessage, ServerResponse } from 'node:http';
import { type MetricReport } from '@zirbel/core/statistics';
export interface StatisticsOptions {
    readonly directory: string;
    readonly instance: string;
    readonly now?: () => number;
    readonly intervalMs?: number;
    readonly failed: (error: unknown) => void;
    readonly view?: {
        readonly html: string;
        readonly js: string;
        readonly css: string;
    };
}
export declare function openStatistics(o: StatisticsOptions): Promise<{
    report(report: MetricReport): void;
    closed(room: string): void;
    snapshot(): import("@zirbel/core/statistics").StatisticsSnapshot;
    flush: () => Promise<void>;
    readonly dropped: number;
    http(req: IncomingMessage, res: ServerResponse): boolean;
    close(): Promise<void>;
}>;
