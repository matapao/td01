/**
 * The catalog zirbel.app serves at /catalog.json (packages/catalog): { signed, key, signature },
 * where signed is the JSON text { format: 1, serial, issued, games: [{ id, version, url, sha256,
 * size, manifest, source }] }. Hosts check the signature before they install anything; the site
 * only shows what is listed, so it reads the signed text and checks the shape of what it uses.
 */
import { isReleaseStage } from './game-manifest.js';
/** The games in catalog.json, in its order; null if it isn't a catalog. */
export function readCatalog(file) {
    const signed = typeof file === 'object' && file !== null ? file.signed : undefined;
    if (typeof signed !== 'string')
        return null;
    let c;
    try {
        c = JSON.parse(signed);
    }
    catch {
        return null;
    }
    if (typeof c !== 'object' || c === null || c.format !== 1)
        return null;
    const list = c.games;
    if (!Array.isArray(list))
        return null;
    const out = [];
    for (const g of list) {
        if (typeof g !== 'object' || g === null)
            continue;
        const e = g;
        const id = e['id'], version = e['version'], size = e['size'], s = e['source'];
        if (typeof id !== 'string' || typeof version !== 'string' || out.some((x) => x.id === id))
            continue;
        const repo = typeof s === 'object' && s !== null ? s.repo : null;
        out.push({
            ...(isReleaseStage(e['stage']) ? { stage: e['stage'] } : {}),
            id,
            version,
            manifest: e['manifest'],
            size: typeof size === 'number' && Number.isSafeInteger(size) && size > 0 ? size : 0,
            source: typeof repo === 'string' && /^https:\/\/[^\s"'<>]+$/i.test(repo) ? repo : null,
        });
    }
    return out;
}
