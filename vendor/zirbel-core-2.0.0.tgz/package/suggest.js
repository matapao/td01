/** The closest of the known ids to a wrong one, for "did you mean". */
export function closest(wrong, known) {
    let best = null, bestD = Math.max(2, Math.floor(wrong.length / 3)) + 1;
    let n = 0;
    for (const k of known) {
        if (++n > 5000)
            break;
        if (Math.abs(k.length - wrong.length) >= bestD)
            continue;
        const d = distance(wrong, k, bestD);
        if (d < bestD) {
            bestD = d;
            best = k;
        }
    }
    return best;
}
/** Levenshtein distance, giving up past max. */
function distance(a, b, max) {
    let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
    for (let i = 1; i <= a.length; i++) {
        const cur = [i];
        let low = i;
        for (let j = 1; j <= b.length; j++) {
            const v = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
            cur.push(v);
            if (v < low)
                low = v;
        }
        if (low >= max)
            return max;
        prev = cur;
    }
    return prev[b.length];
}
