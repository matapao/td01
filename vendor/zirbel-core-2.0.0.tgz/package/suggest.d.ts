/** The closest of the known ids to a wrong one, for "did you mean". */
export declare function closest(wrong: string, known: Iterable<string>): string | null;
