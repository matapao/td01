import { GAME_ID, GAME_VERSION, isBundlePath } from './game-manifest.js';
/** One lifecycle for every renderer. No DOM, platform identity, iframe, network or UI assumption. */
export async function mountGame(game, room, root, driver) {
    if (!GAME_ID.test(game.id) ||
        !GAME_VERSION.test(game.version) ||
        !isBundlePath(game.client) ||
        !/\.m?js$/.test(game.client) ||
        !room)
        throw new Error('Invalid game descriptor');
    const missing = (game.requires ?? []).filter((capability) => !driver.capabilities.has(capability));
    if (missing.length)
        throw new Error('Unsupported game capabilities: ' + missing.join(', '));
    driver.credits(game.id, game.credits);
    const client = await driver.load(game.client);
    if (typeof client?.mount !== 'function')
        throw new Error('Game does not export mount(context)');
    const instance = await client.mount({ root, game: game.id, room, services: driver.services });
    if (!instance || typeof instance.pause !== 'function' || typeof instance.stop !== 'function')
        throw new Error('Game must expose pause and stop');
    let stopped = false;
    return {
        pause(on) {
            if (!stopped)
                instance.pause(on);
        },
        stop() {
            if (!stopped) {
                stopped = true;
                instance.stop();
            }
        },
    };
}
