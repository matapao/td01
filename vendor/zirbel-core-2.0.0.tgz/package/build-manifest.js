/**
 * zirbel.build.json: what a game offers builders (docs/play-and-build.md and build-interface.md 1.2).
 * The host reads it from the revision being built on, strictly: a manifest it can't fully
 * understand turns building off for that game, with the reasons, rather than half on.
 */
import { isBundlePath } from './game-manifest.js';
import { globRegExp, isGlob, matches } from './glob.js';
import { parsePointer } from './patch.js';
export const BUILD_MANIFEST = 'zirbel.build.json';
export const BLOCK_ID = /^[a-z0-9][a-z0-9_-]{0,39}$/;
const PACKAGE = /^(?:@[a-z0-9][a-z0-9._-]*\/)?[a-z0-9][a-z0-9._-]*$/;
const EXACT = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/;
const isObject = (v) => typeof v === 'object' && v !== null && !Array.isArray(v);
/** A path pattern: like a bundle path, with *, ? and {a,b}. */
function isPattern(p) {
    if (typeof p !== 'string' || !p || p.length > 240)
        return false;
    try {
        globRegExp(p);
    }
    catch {
        return false;
    }
    return isBundlePath(p.replace(/\*\*/g, 'x').replace(/[*?{},]/g, 'x'));
}
/** Where a block's ids are: a JSON Pointer whose parts may be * (every item). */
function isIdsPointer(p) {
    if (typeof p !== 'string' || !p.startsWith('/') || p.length > 200)
        return false;
    try {
        parsePointer(p);
        return true;
    }
    catch {
        return false;
    }
}
export function parseBuildManifest(input) {
    const errors = [];
    const bad = (msg) => void errors.push(msg);
    if (!isObject(input))
        return { manifest: null, errors: [`${BUILD_MANIFEST} must be an object`] };
    const m = input;
    const text = (v, key, max) => {
        if (v === undefined || v === null)
            return '';
        if (typeof v !== 'string' || v.length > max) {
            bad(`${key} must be a string of at most ${max} characters`);
            return '';
        }
        return v;
    };
    const lines = (v, key, maxItems, max) => {
        if (v === undefined || v === null)
            return [];
        if (!Array.isArray(v) || v.length > maxItems || v.some((x) => typeof x !== 'string' || x.length > max)) {
            bad(`${key} must be a list of at most ${maxItems} lines of at most ${max} characters`);
            return [];
        }
        return v;
    };
    const path = (v, key, required = false) => {
        if (v === undefined || v === null) {
            if (required)
                bad(`${key} is required`);
            return null;
        }
        if (!isBundlePath(v)) {
            bad(`${key} must be a path in the game, like src/main.ts`);
            return null;
        }
        return v;
    };
    const about = text(m['about'], 'about', 2000);
    const feel = lines(m['feel'], 'feel', 30, 300);
    const blocks = [];
    const rawBlocks = m['blocks'] ?? [];
    if (!Array.isArray(rawBlocks) || rawBlocks.length > 100)
        bad('blocks must be a list of at most 100 blocks');
    else {
        const ids = new Set();
        rawBlocks.forEach((b, i) => {
            if (!isObject(b))
                return bad(`blocks[${i}] must be an object`);
            const id = b['id'];
            if (typeof id !== 'string' || !BLOCK_ID.test(id) || id === 'assets')
                return bad(`blocks[${i}].id must be a short name of a-z, 0-9, - and _ (not "assets")`);
            if (ids.has(id))
                return bad(`blocks: "${id}" twice`);
            ids.add(id);
            const file = b['file'];
            if (!isPattern(file) || !file.startsWith('data/') || !file.endsWith('.json'))
                return bad(`blocks.${id}.file must be a .json file under data/ (or a pattern of them)`);
            const schema = b['schema'];
            if (!isBundlePath(schema) || !schema.endsWith('.json'))
                return bad(`blocks.${id}.schema must be the path of its JSON Schema`);
            if (b['ids'] !== undefined && b['ids'] !== null && !isIdsPointer(b['ids']))
                return bad(`blocks.${id}.ids must be a JSON Pointer such as /pieces/*/id`);
            blocks.push({
                id,
                file,
                schema,
                about: text(b['about'], `blocks.${id}.about`, 1000),
                how: lines(b['how'], `blocks.${id}.how`, 20, 300),
                ids: typeof b['ids'] === 'string' ? b['ids'] : null,
            });
        });
        // One file belongs to one block.
        for (const a of blocks) {
            for (const b of blocks) {
                if (a !== b && !isGlob(a.file) && matches(b.file, a.file))
                    bad(`blocks: ${a.file} belongs to both ${a.id} and ${b.id}`);
            }
        }
    }
    const assets = path(m['assets'], 'assets');
    const budgets = {};
    const rawBudgets = m['budgets'] ?? {};
    if (!isObject(rawBudgets))
        bad('budgets must be an object of names and numbers');
    else {
        for (const [k, v] of Object.entries(rawBudgets)) {
            if (!/^[a-zA-Z][a-zA-Z0-9]{0,31}$/.test(k) ||
                typeof v !== 'number' ||
                !Number.isSafeInteger(v) ||
                v < 0)
                bad(`budgets.${k} must be a whole number`);
            else
                budgets[k] = v;
        }
    }
    const look = path(m['look'], 'look'), check = path(m['check'], 'check'), play = path(m['play'], 'play');
    const apply = m['apply'] ?? 'round';
    if (apply !== 'round' && apply !== 'now')
        bad('apply must be "round" or "now"');
    const review = m['review'] ?? 'creator';
    if (review !== 'creator' && review !== 'owner')
        bad('review must be "creator" or "owner"');
    let build = null;
    const b = m['build'];
    if (b !== undefined && b !== null) {
        if (!isObject(b))
            bad('build must be an object');
        else {
            const entry = path(b['entry'], 'build.entry', true);
            const html = path(b['html'] ?? 'index.html', 'build.html');
            // Static files: patterns, kept at their paths; or { from, to } for one file that moves.
            const rawStatic = b['static'] ?? [];
            const statics = [];
            const moves = [];
            if (!Array.isArray(rawStatic) || rawStatic.length > 50)
                bad('build.static must be a list of path patterns');
            else {
                for (const s of rawStatic) {
                    if (isPattern(s))
                        statics.push(s);
                    else if (isObject(s) && isBundlePath(s['from']) && isBundlePath(s['to']))
                        moves.push({ from: s['from'], to: s['to'] });
                    else
                        bad(`build.static: ${JSON.stringify(s).slice(0, 60)} is neither a path pattern nor { "from", "to" }`);
                }
            }
            const external = b['external'] ?? ['/zirbel-net.js'];
            if (!Array.isArray(external) ||
                external.length > 20 ||
                external.some((x) => typeof x !== 'string' || x.length > 100))
                bad('build.external must be a list of module names');
            const provided = {};
            const rawProvided = b['provided'] ?? {};
            if (!isObject(rawProvided))
                bad('build.provided must be an object of package names and versions');
            else {
                for (const [name, version] of Object.entries(rawProvided)) {
                    if (!PACKAGE.test(name) || typeof version !== 'string' || !EXACT.test(version))
                        bad(`build.provided: ${name} must be an exact version like 0.180.0`);
                    else
                        provided[name] = version;
                }
            }
            const modules = {};
            const rawModules = b['modules'] ?? {};
            if (!isObject(rawModules))
                bad('build.modules must be an object of source and output paths');
            else {
                for (const [from, to] of Object.entries(rawModules)) {
                    if (!isBundlePath(from) || !isBundlePath(to) || !/\.m?js$/.test(to))
                        bad(`build.modules: ${from} → ${String(to)} must map a source path to a .js path`);
                    else
                        modules[from] = to;
                }
            }
            // "entries": { "<output, without .js>": "<source>" } says the same as modules, the other way round.
            const rawEntries = b['entries'] ?? {};
            if (!isObject(rawEntries))
                bad('build.entries must be an object of output names and source paths');
            else {
                for (const [name, from] of Object.entries(rawEntries)) {
                    if (!isBundlePath(name + '.js') || !isBundlePath(from))
                        bad(`build.entries: ${name} → ${String(from)} must name an output and a source path`);
                    else if (from !== entry)
                        modules[from] = name + '.js';
                }
            }
            const aliases = {};
            const rawAliases = b['aliases'] ?? {};
            if (!isObject(rawAliases))
                bad('build.aliases must be an object of import prefixes and folders');
            else {
                for (const [prefix, to] of Object.entries(rawAliases)) {
                    if (!/^\/[A-Za-z0-9._/-]{1,60}\/$/.test(prefix) ||
                        typeof to !== 'string' ||
                        !isBundlePath(to.replace(/\/$/, '')) ||
                        !to.endsWith('/'))
                        bad(`build.aliases: ${prefix} → ${String(to)} must map an import prefix like /shared/ to a folder like shared/`);
                    else
                        aliases[prefix] = to;
                }
            }
            if (entry && html) {
                build = {
                    entry,
                    html,
                    static: statics,
                    external: Array.isArray(external) ? external : [],
                    provided,
                    modules,
                    moves,
                    aliases,
                };
            }
        }
    }
    const c = m['checks'] ?? {};
    let checks = { types: null, tests: null };
    if (!isObject(c))
        bad('checks must be an object');
    else {
        const tests = c['tests'];
        if (tests !== undefined && tests !== null && !isPattern(tests))
            bad('checks.tests must be a path pattern, like test/*.test.ts');
        checks = { types: path(c['types'], 'checks.types'), tests: isPattern(tests) ? tests : null };
    }
    const code = [];
    const rawCode = m['code'] ?? [];
    if (!Array.isArray(rawCode) || rawCode.length > 200)
        bad('code must be a list of at most 200 entries');
    else {
        rawCode.forEach((e, i) => {
            if (!isObject(e) || !isPattern(e['path']))
                return bad(`code[${i}].path must be a path or pattern in the game`);
            if (e['editable'] !== undefined && typeof e['editable'] !== 'boolean')
                return bad(`code[${i}].editable must be true or false`);
            code.push({
                path: e['path'],
                about: text(e['about'], `code[${i}].about`, 1000),
                editable: e['editable'] === true,
                why: text(e['why'], `code[${i}].why`, 300),
                hooks: lines(e['hooks'], `code[${i}].hooks`, 20, 300),
            });
        });
    }
    if (errors.length)
        return { manifest: null, errors };
    return {
        manifest: {
            about,
            feel,
            blocks,
            assets,
            budgets,
            look,
            check,
            play,
            apply: apply,
            review: review,
            build,
            checks,
            code,
        },
        errors,
    };
}
/** The block a file belongs to, if any. */
export function blockOf(manifest, path) {
    return manifest.blocks.find((b) => (isGlob(b.file) ? matches(b.file, path) : b.file === path)) ?? null;
}
/** Whether agents may propose a change to this file in the reviewed Code lane. The first entry that matches decides. */
export function codeEditable(manifest, path) {
    if (blockOf(manifest, path))
        return { editable: true, why: '' };
    if (manifest.checks.tests && matches(manifest.checks.tests, path))
        return { editable: true, why: '' };
    for (const e of manifest.code)
        if (matches(e.path, path))
            return { editable: e.editable, why: e.why || (e.editable ? '' : 'the game keeps it for people') };
    return { editable: false, why: 'it is not in the code map (zirbel.build.json "code")' };
}
/** Where a module named in the manifest is in an engine: its built form under agent/ (or as it is, if it is .js already). */
export function builtModule(source, kind) {
    const out = [`agent/${kind}.js`];
    if (/\.m?js$/.test(source))
        out.unshift(source);
    return out;
}
