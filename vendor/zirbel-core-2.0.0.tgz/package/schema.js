/**
 * JSON Schema, draft 2020-12, for the blocks agents compose: a small validator compiled once per
 * schema into closures, so checking a block of thousands of values takes a few milliseconds.
 *
 * It supports the keywords games need (build-interface.md 1.3) and refuses a schema that uses any
 * other, so nothing is ever silently left unchecked. Its problems name the place, the rule and the
 * field's own description, because agents read them to fix what they proposed.
 *
 * One extension, ignored by other validators: "x-zirbel-ref": "<block id>" on a string records the
 * value as a reference, which the data checks look up in that block's ids (or the asset catalogue).
 */
import { jsonEqual, parsePointer } from './patch.js';
export class SchemaError extends Error {
}
const ANNOTATIONS = new Set([
    '$schema',
    '$id',
    '$comment',
    'title',
    'description',
    'default',
    'examples',
    'deprecated',
    'readOnly',
    'writeOnly',
    'format',
    '$defs',
    'definitions',
    'contentMediaType',
    'contentEncoding',
]);
const KEYWORDS = new Set([
    'type',
    'enum',
    'const',
    'properties',
    'required',
    'additionalProperties',
    'patternProperties',
    'propertyNames',
    'items',
    'prefixItems',
    'minItems',
    'maxItems',
    'uniqueItems',
    'contains',
    'minContains',
    'maxContains',
    'minimum',
    'maximum',
    'exclusiveMinimum',
    'exclusiveMaximum',
    'multipleOf',
    'minLength',
    'maxLength',
    'pattern',
    'minProperties',
    'maxProperties',
    'allOf',
    'anyOf',
    'oneOf',
    'not',
    'if',
    'then',
    'else',
    'dependentRequired',
    'dependentSchemas',
    '$ref',
    'x-zirbel-ref',
]);
const TYPES = new Set(['null', 'boolean', 'object', 'array', 'number', 'string', 'integer']);
const DRAFT = 'https://json-schema.org/draft/2020-12/schema';
const isObject = (v) => typeof v === 'object' && v !== null && !Array.isArray(v);
const has = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
/** A value's JSON with every object's keys in order: equal values (as JSON Schema means it), equal strings. */
function canonical(v) {
    if (Array.isArray(v))
        return `[${v.map(canonical).join(',')}]`;
    if (isObject(v))
        return `{${Object.keys(v)
            .sort()
            .map((k) => `${JSON.stringify(k)}:${canonical(v[k])}`)
            .join(',')}}`;
    return JSON.stringify(v) ?? 'null';
}
function typeOf(v) {
    if (v === null)
        return 'null';
    if (Array.isArray(v))
        return 'array';
    if (typeof v === 'number')
        return Number.isInteger(v) ? 'integer' : 'number';
    return typeof v;
}
const show = (v) => {
    const s = JSON.stringify(v) ?? String(v);
    return s.length > 50 ? s.slice(0, 47) + '…' : s;
};
/** Code points, as JSON Schema counts a string's length. */
function length(s) {
    let n = 0;
    for (let i = 0; i < s.length; i++) {
        const c = s.charCodeAt(i);
        if (c < 0xd800 || c > 0xdbff)
            n++;
    }
    return n;
}
const esc = (key) => key.includes('~') || key.includes('/') ? key.replace(/~/g, '~0').replace(/\//g, '~1') : key;
function pointer(at) {
    let s = '';
    for (const k of at)
        s += '/' + (typeof k === 'number' ? String(k) : esc(k));
    return s;
}
const article = (t) => (/^[aeiou]/.test(t) ? 'an ' : 'a ') + t;
function clip(text) {
    return text.length > 120 ? text.slice(0, 117) + '…' : text;
}
/** A compiled schema: validate() any number of documents. */
export class Validator {
    root;
    /**
     * Compiles a schema. `file` is its path in the game, for $refs to other schema files by relative
     * path, which `load` reads. Throws SchemaError for a schema it can't fully check.
     */
    constructor(schema, o = {}) {
        const docs = new Map([[o.file ?? '', schema]]);
        const compiled = new Map(); // "file#pointer": also while compiling, for cycles
        const resolveFile = (from, ref) => {
            if (!ref)
                return from;
            if (/^[a-z][a-z0-9+.-]*:/i.test(ref) || ref.startsWith('/'))
                throw new SchemaError(`$ref "${ref}": only refs inside the game, by relative path, are supported`);
            const parts = [];
            for (const s of ((from.includes('/') ? from.slice(0, from.lastIndexOf('/') + 1) : '') + ref).split('/')) {
                if (s === '..')
                    parts.pop();
                else if (s !== '.' && s !== '')
                    parts.push(s);
            }
            return parts.join('/');
        };
        const doc = (file) => {
            if (docs.has(file))
                return docs.get(file);
            if (!o.load)
                throw new SchemaError(`$ref to ${file}: no other schema files can be read here`);
            const d = o.load(file);
            if (d === undefined)
                throw new SchemaError(`$ref to ${file}: no such schema file`);
            docs.set(file, d);
            return d;
        };
        const at = (file, ptr) => {
            const key = file + '#' + ptr;
            const done = compiled.get(key);
            if (done)
                return done;
            let target = doc(file);
            for (const p of parsePointer(ptr)) {
                target =
                    isObject(target) || Array.isArray(target) ? target[p] : undefined;
                if (target === undefined)
                    throw new SchemaError(`$ref "${file}#${ptr}": nothing there`);
            }
            // A $ref back up the tree: the check is looked up when it runs, not when it is compiled.
            let real = null;
            compiled.set(key, (v, ctx) => real(v, ctx));
            real = compile(target, file, ptr);
            compiled.set(key, real);
            return real;
        };
        const compile = (s, file, where) => {
            if (s === true)
                return () => true;
            if (s === false)
                return (_v, ctx) => fail(ctx, 'nothing is allowed here');
            if (!isObject(s))
                throw new SchemaError(`${where || '/'}: a schema must be an object or a boolean`);
            if (s['$schema'] !== undefined && s['$schema'] !== DRAFT && s['$schema'] !== DRAFT + '#')
                throw new SchemaError(`${where || '/'}: only draft 2020-12 ("${DRAFT}") is checked here`);
            for (const k of Object.keys(s)) {
                if (!KEYWORDS.has(k) && !ANNOTATIONS.has(k) && !k.startsWith('x-'))
                    throw new SchemaError(`${where || '/'}: "${k}" is not a keyword this host checks`);
            }
            const about = typeof s['description'] === 'string'
                ? s['description']
                : typeof s['title'] === 'string'
                    ? s['title']
                    : '';
            const say = (msg) => (about ? `${msg} (${clip(about)})` : msg);
            const sub = (k) => compile(s[k], file, `${where}/${k}`);
            const checks = [];
            const num = (k) => {
                const v = s[k];
                if (v === undefined)
                    return undefined;
                if (typeof v !== 'number' || !Number.isFinite(v))
                    throw new SchemaError(`${where}/${k} must be a number`);
                return v;
            };
            const count = (k) => {
                const v = num(k);
                if (v !== undefined && (!Number.isInteger(v) || v < 0))
                    throw new SchemaError(`${where}/${k} must be a whole number`);
                return v;
            };
            const list = (k) => {
                const l = s[k];
                if (l === undefined)
                    return null;
                if (!Array.isArray(l) || !l.length)
                    throw new SchemaError(`${where}/${k} must be a list of schemas`);
                return l.map((x, i) => compile(x, file, `${where}/${k}/${i}`));
            };
            if (s['$ref'] !== undefined) {
                const ref = s['$ref'];
                if (typeof ref !== 'string')
                    throw new SchemaError(`${where}/$ref must be a string`);
                const hash = ref.indexOf('#');
                const target = resolveFile(file, hash >= 0 ? ref.slice(0, hash) : ref);
                const ptr = hash >= 0 ? decodeURIComponent(ref.slice(hash + 1)) : '';
                if (ptr && !ptr.startsWith('/'))
                    throw new SchemaError(`$ref "${ref}": anchors are not supported, use a JSON Pointer (#/$defs/…)`);
                checks.push(at(target, ptr)); // compiled now: a broken ref fails at once, not on the first document
            }
            const type = s['type'];
            if (type !== undefined) {
                const types = Array.isArray(type) ? type : [type];
                for (const t of types)
                    if (typeof t !== 'string' || !TYPES.has(t))
                        throw new SchemaError(`${where}/type: "${String(t)}" is not a JSON Schema type`);
                const allowed = new Set(types);
                const wanted = types.map((x) => article(String(x))).join(' or ');
                checks.push((v, ctx) => {
                    const t = typeOf(v);
                    return (allowed.has(t) ||
                        (t === 'integer' && allowed.has('number')) ||
                        fail(ctx, say(`${show(v)} is ${article(t)}, not ${wanted}`)));
                });
            }
            if (s['enum'] !== undefined) {
                const options = s['enum'];
                if (!Array.isArray(options) || !options.length)
                    throw new SchemaError(`${where}/enum must be a list`);
                const plain = options.every((x) => x === null || typeof x !== 'object');
                const set = new Set(options);
                const text = options.length <= 12
                    ? options.map(show).join(', ')
                    : options.slice(0, 12).map(show).join(', ') + `, … (${options.length} in all)`;
                checks.push((v, ctx) => (plain ? set.has(v) : options.some((x) => jsonEqual(x, v))) ||
                    fail(ctx, say(`${show(v)} is not one of ${text}`)));
            }
            if (s['const'] !== undefined) {
                const c = s['const'];
                checks.push((v, ctx) => jsonEqual(c, v) || fail(ctx, say(`must be ${show(c)}`)));
            }
            // Numbers.
            const minimum = num('minimum'), maximum = num('maximum'), exMin = num('exclusiveMinimum'), exMax = num('exclusiveMaximum'), mult = num('multipleOf');
            if (mult !== undefined && !(mult > 0))
                throw new SchemaError(`${where}/multipleOf must be above 0`);
            if (minimum !== undefined ||
                maximum !== undefined ||
                exMin !== undefined ||
                exMax !== undefined ||
                mult !== undefined) {
                checks.push((v, ctx) => {
                    if (typeof v !== 'number')
                        return true;
                    if (minimum !== undefined && v < minimum)
                        return fail(ctx, say(`${v} is less than the minimum ${minimum}`));
                    if (maximum !== undefined && v > maximum)
                        return fail(ctx, say(`${v} is more than the maximum ${maximum}`));
                    if (exMin !== undefined && v <= exMin)
                        return fail(ctx, say(`${v} must be more than ${exMin}`));
                    if (exMax !== undefined && v >= exMax)
                        return fail(ctx, say(`${v} must be less than ${exMax}`));
                    if (mult !== undefined) {
                        const q = v / mult;
                        if (!Number.isFinite(q) || Math.abs(q - Math.round(q)) > 1e-9 * Math.max(1, Math.abs(q)))
                            return fail(ctx, say(`${v} is not a multiple of ${mult}`));
                    }
                    return true;
                });
            }
            // Strings.
            const minLength = count('minLength'), maxLength = count('maxLength');
            let re = null;
            if (s['pattern'] !== undefined) {
                if (typeof s['pattern'] !== 'string')
                    throw new SchemaError(`${where}/pattern must be a string`);
                try {
                    re = new RegExp(s['pattern'], 'u');
                }
                catch (e) {
                    throw new SchemaError(`${where}/pattern: ${e.message}`);
                }
            }
            if (minLength !== undefined || maxLength !== undefined || re) {
                const pattern = re;
                checks.push((v, ctx) => {
                    if (typeof v !== 'string')
                        return true;
                    const n = minLength !== undefined || maxLength !== undefined ? length(v) : 0;
                    if (minLength !== undefined && n < minLength)
                        return fail(ctx, say(`"${v.slice(0, 40)}" is shorter than ${minLength} characters`));
                    if (maxLength !== undefined && n > maxLength)
                        return fail(ctx, say(`${n} characters: at most ${maxLength}`));
                    if (pattern && !pattern.test(v))
                        return fail(ctx, say(`"${v.slice(0, 40)}" doesn't match ${pattern.source}`));
                    return true;
                });
            }
            if (s['x-zirbel-ref'] !== undefined) {
                const target = s['x-zirbel-ref'];
                if (typeof target !== 'string' || !/^[a-z0-9][a-z0-9_-]{0,39}$/.test(target))
                    throw new SchemaError(`${where}/x-zirbel-ref must name a block id, or "assets"`);
                checks.push((v, ctx) => {
                    if (typeof v === 'string')
                        ctx.refs.push({ path: pointer(ctx.at), value: v, target });
                    return true;
                });
            }
            // Arrays.
            const prefix = s['prefixItems'];
            if (prefix !== undefined && !Array.isArray(prefix))
                throw new SchemaError(`${where}/prefixItems must be a list`);
            const prefixChecks = prefix?.map((p, i) => compile(p, file, `${where}/prefixItems/${i}`)) ?? [];
            if (Array.isArray(s['items']))
                throw new SchemaError(`${where}/items: a list here is draft-07; in 2020-12 it is prefixItems`);
            const items = s['items'] !== undefined ? sub('items') : null;
            const minItems = count('minItems'), maxItems = count('maxItems');
            const unique = s['uniqueItems'] === true;
            const contains = s['contains'] !== undefined ? sub('contains') : null;
            const minContains = count('minContains') ?? 1, maxContains = count('maxContains');
            if (prefixChecks.length ||
                items ||
                minItems !== undefined ||
                maxItems !== undefined ||
                unique ||
                contains) {
                checks.push((v, ctx) => {
                    if (!Array.isArray(v))
                        return true;
                    let ok = true;
                    if (minItems !== undefined && v.length < minItems)
                        ok = fail(ctx, say(`${v.length} items: at least ${minItems}`));
                    if (maxItems !== undefined && v.length > maxItems)
                        ok = fail(ctx, say(`${v.length} items: at most ${maxItems}`));
                    const path = ctx.at;
                    for (let i = 0; i < v.length && ctx.problems.length < ctx.max; i++) {
                        const c = i < prefixChecks.length ? prefixChecks[i] : items;
                        if (!c)
                            continue;
                        path.push(i);
                        if (!c(v[i], ctx))
                            ok = false;
                        path.pop();
                    }
                    if (unique) {
                        // By each item's canonical JSON: linear, not every pair.
                        const seen = new Map();
                        for (let i = 0; i < v.length; i++) {
                            const k = canonical(v[i]);
                            const j = seen.get(k);
                            if (j !== undefined) {
                                ok = failAt(ctx, i, say(`the same as item ${j}: items must be unique`));
                                break;
                            }
                            seen.set(k, i);
                        }
                    }
                    if (contains) {
                        let n = 0;
                        for (const x of v)
                            if (contains(x, quiet(ctx)))
                                n++;
                        if (n < minContains)
                            ok = fail(ctx, say(`${n} items match "contains": at least ${minContains}`));
                        if (maxContains !== undefined && n > maxContains)
                            ok = fail(ctx, say(`${n} items match "contains": at most ${maxContains}`));
                    }
                    return ok;
                });
            }
            // Objects.
            const props = s['properties'];
            if (props !== undefined && !isObject(props))
                throw new SchemaError(`${where}/properties must be an object`);
            const propChecks = new Map();
            for (const [k, p] of Object.entries(props ?? {}))
                propChecks.set(k, compile(p, file, `${where}/properties/${esc(k)}`));
            const pats = s['patternProperties'];
            if (pats !== undefined && !isObject(pats))
                throw new SchemaError(`${where}/patternProperties must be an object`);
            const patChecks = Object.entries(pats ?? {}).map(([source, p]) => {
                let r;
                try {
                    r = new RegExp(source, 'u');
                }
                catch (e) {
                    throw new SchemaError(`${where}/patternProperties: ${e.message}`);
                }
                return [r, compile(p, file, `${where}/patternProperties/${esc(source)}`)];
            });
            const additional = s['additionalProperties'] !== undefined ? sub('additionalProperties') : null;
            const closed = s['additionalProperties'] === false;
            const names = s['propertyNames'] !== undefined ? sub('propertyNames') : null;
            const required = s['required'];
            if (required !== undefined && (!Array.isArray(required) || required.some((r) => typeof r !== 'string')))
                throw new SchemaError(`${where}/required must be a list of names`);
            const minProps = count('minProperties'), maxProps = count('maxProperties');
            const depReq = s['dependentRequired'];
            if (depReq !== undefined && !isObject(depReq))
                throw new SchemaError(`${where}/dependentRequired must be an object`);
            const depSchemas = s['dependentSchemas'];
            if (depSchemas !== undefined && !isObject(depSchemas))
                throw new SchemaError(`${where}/dependentSchemas must be an object`);
            const depChecks = Object.entries(depSchemas ?? {}).map(([k, p]) => [k, compile(p, file, `${where}/dependentSchemas/${esc(k)}`)]);
            if (propChecks.size ||
                patChecks.length ||
                additional ||
                names ||
                required ||
                minProps !== undefined ||
                maxProps !== undefined ||
                depReq ||
                depChecks.length) {
                const req = required ?? [];
                const deps = Object.entries(depReq ?? {});
                const known = Object.keys(props ?? {});
                const notHere = `is not a property here${known.length ? `: the properties are ${known.slice(0, 16).join(', ')}` : ''}`;
                checks.push((v, ctx) => {
                    if (!isObject(v))
                        return true;
                    let ok = true;
                    for (const r of req)
                        if (!has(v, r))
                            ok = failAt(ctx, r, `is missing: it is required${describe(props, r)}`);
                    const keys = Object.keys(v);
                    if (minProps !== undefined && keys.length < minProps)
                        ok = fail(ctx, say(`${keys.length} properties: at least ${minProps}`));
                    if (maxProps !== undefined && keys.length > maxProps)
                        ok = fail(ctx, say(`${keys.length} properties: at most ${maxProps}`));
                    const path = ctx.at;
                    for (const k of keys) {
                        if (ctx.problems.length >= ctx.max)
                            break;
                        path.push(k);
                        if (names && !names(k, ctx))
                            ok = false;
                        let matched = false;
                        const pc = propChecks.get(k);
                        if (pc) {
                            matched = true;
                            if (!pc(v[k], ctx))
                                ok = false;
                        }
                        for (const [r, c] of patChecks) {
                            if (r.test(k)) {
                                matched = true;
                                if (!c(v[k], ctx))
                                    ok = false;
                            }
                        }
                        if (!matched && additional) {
                            if (closed)
                                ok = fail(ctx, notHere);
                            else if (!additional(v[k], ctx))
                                ok = false;
                        }
                        path.pop();
                    }
                    for (const [k, need] of deps) {
                        if (!has(v, k) || !Array.isArray(need))
                            continue;
                        for (const r of need)
                            if (typeof r === 'string' && !has(v, r))
                                ok = failAt(ctx, r, `is missing: ${k} needs it`);
                    }
                    for (const [k, c] of depChecks)
                        if (has(v, k) && !c(v, ctx))
                            ok = false;
                    return ok;
                });
            }
            // Combinations.
            const allOf = list('allOf'), anyOf = list('anyOf'), oneOf = list('oneOf');
            if (allOf)
                checks.push((v, ctx) => allOf.reduce((ok, c) => c(v, ctx) && ok, true));
            if (anyOf) {
                checks.push((v, ctx) => {
                    const tries = anyOf.map((c) => attempt(c, v, ctx));
                    const hit = tries.find((t) => t.ok);
                    if (hit) {
                        ctx.refs.push(...hit.refs);
                        return true;
                    }
                    return failBest(ctx, say(`matches none of the ${anyOf.length} allowed forms`), tries);
                });
            }
            if (oneOf) {
                checks.push((v, ctx) => {
                    const tries = oneOf.map((c) => attempt(c, v, ctx));
                    const hits = tries.filter((t) => t.ok);
                    if (hits.length === 1) {
                        ctx.refs.push(...hits[0].refs);
                        return true;
                    }
                    if (hits.length > 1)
                        return fail(ctx, say(`matches ${hits.length} of the forms where exactly one must match`));
                    return failBest(ctx, say(`matches none of the ${oneOf.length} allowed forms`), tries);
                });
            }
            if (s['not'] !== undefined) {
                const not = sub('not');
                checks.push((v, ctx) => !attempt(not, v, ctx).ok || fail(ctx, say('matches a form that is not allowed')));
            }
            if (s['if'] !== undefined) {
                const cond = sub('if');
                const then = s['then'] !== undefined ? sub('then') : null;
                const otherwise = s['else'] !== undefined ? sub('else') : null;
                checks.push((v, ctx) => {
                    const t = attempt(cond, v, ctx);
                    if (t.ok) {
                        ctx.refs.push(...t.refs);
                        return then ? then(v, ctx) : true;
                    }
                    return otherwise ? otherwise(v, ctx) : true;
                });
            }
            if (checks.length === 0)
                return () => true;
            if (checks.length === 1)
                return checks[0];
            return (v, ctx) => {
                let ok = true;
                for (const c of checks) {
                    if (!c(v, ctx))
                        ok = false;
                    if (ctx.problems.length >= ctx.max)
                        return false;
                }
                return ok;
            };
        };
        this.root = at(o.file ?? '', '');
    }
    /** Checks a document: its problems (at most max), and the references it makes. */
    validate(value, max = 20) {
        const ctx = { problems: [], refs: [], max, at: [] };
        const ok = this.root(value, ctx);
        return { ok: ok && ctx.problems.length === 0, problems: ctx.problems, refs: ctx.refs };
    }
}
function fail(ctx, message) {
    if (ctx.problems.length < ctx.max)
        ctx.problems.push({ path: pointer(ctx.at), message });
    return false;
}
/** A problem one step further in: a missing property, a repeated item. */
function failAt(ctx, key, message) {
    ctx.at.push(key);
    fail(ctx, message);
    ctx.at.pop();
    return false;
}
/** A context that keeps next to nothing: for "contains", where items that don't match are expected. */
function quiet(ctx) {
    return { problems: [], refs: [], max: 1, at: [...ctx.at] };
}
function attempt(c, v, ctx) {
    const sub = { problems: [], refs: [], max: ctx.max, at: [...ctx.at] };
    const ok = c(v, sub) && sub.problems.length === 0;
    return { ok, problems: sub.problems, refs: sub.refs };
}
/**
 * None of the forms matched: the problems of the form that came closest, then that none matched.
 * The closest form's problems come first, because they say what to fix (a union inside a union
 * puts its own first in turn, so the deepest problem leads).
 */
function failBest(ctx, message, tries) {
    // Closest: the fewest problems, and among those the deepest (it got furthest in).
    const depth = (t) => Math.max(...t.problems.map((p) => p.path.length));
    let best = null;
    for (const t of tries) {
        if (!t.problems.length)
            continue;
        if (!best ||
            t.problems.length < best.problems.length ||
            (t.problems.length === best.problems.length && depth(t) > depth(best)))
            best = t;
    }
    for (const p of best?.problems.slice(0, 3) ?? [])
        if (ctx.problems.length < ctx.max)
            ctx.problems.push(p);
    fail(ctx, message);
    return false;
}
function describe(props, key) {
    const p = isObject(props) ? props[key] : undefined;
    const d = isObject(p) && typeof p['description'] === 'string' ? p['description'] : '';
    return d ? ` (${clip(d)})` : '';
}
/**
 * What a schema should have so agents can work with it (the contract): a description on every
 * property, and a minimum and a maximum on every number. For the game's creator, not a gate.
 */
export function lintSchema(schema) {
    const out = [];
    const walk = (s, where, isProperty) => {
        if (!isObject(s) || out.length > 50)
            return;
        if (isProperty && typeof s['description'] !== 'string' && s['$ref'] === undefined)
            out.push({ path: where, message: 'has no description: agents read it' });
        const t = s['type'];
        const numeric = t === 'number' ||
            t === 'integer' ||
            (Array.isArray(t) && t.some((x) => x === 'number' || x === 'integer'));
        if (numeric && s['enum'] === undefined && s['const'] === undefined) {
            if (s['minimum'] === undefined && s['exclusiveMinimum'] === undefined)
                out.push({ path: where, message: 'a number with no minimum' });
            if (s['maximum'] === undefined && s['exclusiveMaximum'] === undefined)
                out.push({ path: where, message: 'a number with no maximum' });
        }
        for (const [k, v] of Object.entries(isObject(s['properties']) ? s['properties'] : {}))
            walk(v, `${where}/properties/${esc(k)}`, true);
        for (const [k, v] of Object.entries(isObject(s['patternProperties']) ? s['patternProperties'] : {}))
            walk(v, `${where}/patternProperties/${esc(k)}`, true);
        for (const [k, v] of Object.entries(isObject(s['$defs']) ? s['$defs'] : {}))
            walk(v, `${where}/$defs/${esc(k)}`, false);
        for (const k of [
            'items',
            'additionalProperties',
            'contains',
            'not',
            'if',
            'then',
            'else',
            'propertyNames',
        ])
            walk(s[k], `${where}/${k}`, false);
        for (const k of ['prefixItems', 'allOf', 'anyOf', 'oneOf']) {
            const l = s[k];
            if (Array.isArray(l))
                l.forEach((x, i) => walk(x, `${where}/${k}/${i}`, false));
        }
    };
    walk(schema, '', false);
    return out;
}
