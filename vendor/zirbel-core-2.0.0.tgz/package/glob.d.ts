/**
 * Path patterns, as manifests write them: `*` within one folder, `**` across folders, `?` one
 * character, `{a,b}` either. Paths use / and never start with it.
 */
export declare function globRegExp(glob: string): RegExp;
export declare const matches: (glob: string, path: string) => boolean;
/** Whether a pattern has any wildcard: otherwise it names one path. */
export declare const isGlob: (glob: string) => boolean;
