import { type Credit } from './game-manifest.ts';
export interface GameDescriptor {
    id: string;
    version: string;
    client: string;
    credits: readonly Credit[];
    requires?: readonly string[];
}
export interface GameInstance {
    pause(paused: boolean): void;
    stop(): void;
}
export interface GameClient {
    mount(context: {
        root: unknown;
        game: string;
        room: string;
        services: Readonly<Record<string, unknown>>;
    }): GameInstance | Promise<GameInstance>;
}
export interface GameDriver {
    readonly capabilities: ReadonlySet<string>;
    load(client: string): Promise<GameClient>;
    credits(game: string, credits: readonly Credit[]): void;
    readonly services: Readonly<Record<string, unknown>>;
}
/** One lifecycle for every renderer. No DOM, platform identity, iframe, network or UI assumption. */
export declare function mountGame(game: GameDescriptor, room: string, root: unknown, driver: GameDriver): Promise<GameInstance>;
