/** Portable, descriptive provider inventory. Discovery never grants authority to invoke an operation. */
import { type Json } from './patch.ts';
export declare const PROVIDER_DISCOVERY_VERSION: 'zirbel.provider/discovery-v1';
export declare const PROVIDER_CONTRACT_LIMITS: Readonly<{
    capabilities: 128;
    scopes: 32;
    identifierLength: 160;
    reasonLength: 512;
    schemaBytes: 32768;
    schemaDepth: 16;
    documentBytes: 1048576;
    documentNodes: 32768;
}>;
export interface CapabilityAvailability {
    readonly status: 'supported' | 'unsupported' | 'manual' | 'approval-required';
    readonly reason?: string;
}
export type CapabilityEffect = 'read' | 'write' | 'execute' | 'publish';
export interface CapabilityDescriptor {
    readonly id: string;
    readonly version: string;
    readonly availability: CapabilityAvailability;
    readonly inputSchema: Json;
    readonly outputSchema: Json;
    readonly authorization: {
        readonly required: boolean;
        /** All listed scopes are required; these labels do not replace the owner's authorization check. */
        readonly scopes: readonly string[];
    };
    readonly effects: readonly CapabilityEffect[];
    readonly execution: {
        readonly environment: 'portable' | 'browser' | 'server' | 'native' | 'external' | 'manual';
    };
    readonly delivery: {
        readonly mode: 'request-response' | 'stream' | 'subscription' | 'job';
        readonly ordering: 'none' | 'per-resource' | 'total';
        readonly replay: boolean;
    };
    readonly limits: {
        /** Null advertises no bound. Consumers must still enforce their own resource limits. */
        readonly maxInputBytes: number | null;
        readonly maxOutputBytes: number | null;
        readonly timeoutMs: number | null;
    };
    /** Opaque adapter policy identifier, never credentials or a delivery URL. */
    readonly policy: string;
}
export interface ProviderDiscovery {
    readonly version: typeof PROVIDER_DISCOVERY_VERSION;
    readonly provider: string;
    readonly capabilities: readonly CapabilityDescriptor[];
}
export declare class ProviderContractError extends Error {
}
/** Decode and copy an untrusted capability. Supported availability is never an authorization result. */
export declare function parseCapabilityDescriptor(value: unknown): CapabilityDescriptor;
/** Validates the envelope version, rejects duplicate identities and returns deterministic ID ordering. */
export declare function parseProviderDiscovery(value: unknown): ProviderDiscovery;
/** Adapter authors pass their implemented inventory through the same boundary used by remote clients. */
export declare function createProviderDiscovery(provider: string, capabilities: readonly CapabilityDescriptor[]): ProviderDiscovery;
