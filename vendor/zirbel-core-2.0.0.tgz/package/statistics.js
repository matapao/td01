/** Anonymous statistics. Room keys exist only while combining active gauges, never in snapshots. */
import { GAME_ID, GAME_VERSION, parseMetrics } from './game-manifest.js';
const MAX_SERIES = 4096;
const MAX_HISTORY = 120;
const MAX_SCORES = 10;
const REVISION = /^[a-zA-Z0-9._-]{1,60}$/;
const INSTANCE = /^[a-zA-Z0-9_-]{1,64}$/;
const finite = (v) => typeof v === 'number' && Number.isFinite(v) && Math.abs(v) <= Number.MAX_SAFE_INTEGER;
const object = (v) => !!v && typeof v === 'object' && !Array.isArray(v);
const order = (a, b) => (a < b ? -1 : a > b ? 1 : 0);
const familyOf = (r) => JSON.stringify([r.game, r.version, r.revision, r.from, r.metric.name]);
const keyOf = (r) => JSON.stringify([familyOf(r), Object.entries(r.labels).sort(([a], [b]) => order(a, b))]);
const definitionOf = (metric) => JSON.stringify([
    metric.type,
    metric.record ?? null,
    metric.help,
    metric.unit,
    metric.buckets,
    Object.entries(metric.labels)
        .sort(([a], [b]) => order(a, b))
        .map(([key, values]) => [key, [...values].sort(order)]),
]);
function readMetric(value) {
    if (!object(value))
        return null;
    // Normalized metrics always contain buckets: []; manifests omit it on gauges and counters.
    const input = { ...value };
    if (input['type'] !== 'histogram' && input['buckets'] !== undefined) {
        if (!Array.isArray(input['buckets']) || input['buckets'].length !== 0)
            return null;
        delete input['buckets'];
    }
    if (input['labels'] === null)
        return null;
    let invalid = false;
    const metrics = parseMetrics([input], () => {
        invalid = true;
    });
    const metric = metrics[0];
    if (invalid || !metric)
        return null;
    return {
        ...metric,
        buckets: [...metric.buckets],
        labels: Object.fromEntries(Object.entries(metric.labels).map(([key, values]) => [key, [...values]])),
    };
}
function readLabels(value, metric) {
    if (!object(value) || Object.keys(value).length !== Object.keys(metric.labels).length)
        return null;
    const labels = {};
    for (const [key, values] of Object.entries(metric.labels)) {
        const label = value[key];
        if (typeof label !== 'string' || !values.includes(label))
            return null;
        labels[key] = label;
    }
    return labels;
}
function bounded(value, fallback, max) {
    const n = value ?? fallback;
    if (!Number.isSafeInteger(n) || n < 1 || n > max)
        throw new Error('Invalid statistics limit');
    return n;
}
function copy(c) {
    return {
        ...c,
        metric: {
            ...c.metric,
            buckets: [...c.metric.buckets],
            labels: Object.fromEntries(Object.entries(c.metric.labels).map(([key, values]) => [key, [...values]])),
        },
        labels: { ...c.labels },
        scores: [...c.scores],
        history: c.history.map(([t, n]) => [t, n]),
    };
}
export class GameStatistics {
    cells = new Map();
    definitions = new Map();
    gauges = new Map();
    gaugeValues = 0;
    maxSeries;
    maxHistory;
    maxRoomsPerSeries;
    maxGaugeValues;
    instance;
    constructor(instance, limits = {}) {
        if (!INSTANCE.test(instance))
            throw new Error('Invalid statistics instance');
        this.instance = instance;
        this.maxSeries = bounded(limits.maxSeries, 2048, MAX_SERIES);
        this.maxHistory = bounded(limits.maxHistory, MAX_HISTORY, MAX_HISTORY);
        this.maxRoomsPerSeries = bounded(limits.maxRoomsPerSeries, 2000, 2000);
        this.maxGaugeValues = bounded(limits.maxGaugeValues, 65_536, 65_536);
    }
    report(r) {
        if (!r ||
            !GAME_ID.test(r.game) ||
            !GAME_VERSION.test(r.version) ||
            !finite(r.value) ||
            typeof r.revision !== 'string' ||
            !REVISION.test(r.revision) ||
            typeof r.room !== 'string' ||
            !r.room.length ||
            r.room.length > 128 ||
            (r.from !== 'authority' && r.from !== 'host'))
            return false;
        const metric = readMetric(r.metric);
        if (!metric || (metric.type === 'counter' && r.value < 0))
            return false;
        const labels = readLabels(r.labels, metric);
        if (!labels)
            return false;
        const definition = definitionOf(metric);
        const family = familyOf({ ...r, metric });
        if (this.definitions.has(family) && this.definitions.get(family) !== definition)
            return false;
        const key = keyOf({ ...r, metric, labels });
        const previous = this.cells.get(key);
        if (!previous && this.cells.size >= this.maxSeries)
            return false;
        if (previous && (!Number.isSafeInteger(previous.count + 1) || !finite(previous.sum + r.value)))
            return false;
        const active = metric.type === 'gauge' && !metric.record;
        const rooms = this.gauges.get(key);
        let current = r.value;
        if (active) {
            // Keep every possible subset finite when a room closes, even with signed gauge values.
            if (Math.abs(r.value) > Number.MAX_SAFE_INTEGER / this.maxRoomsPerSeries)
                return false;
            if (!rooms?.has(r.room) &&
                ((rooms?.size ?? 0) >= this.maxRoomsPerSeries || this.gaugeValues >= this.maxGaugeValues))
                return false;
            current =
                [...(rooms?.values() ?? [])].reduce((sum, n) => sum + n, 0) - (rooms?.get(r.room) ?? 0) + r.value;
            if (!finite(current))
                return false;
        }
        const c = previous ?? {
            game: r.game,
            version: r.version,
            revision: r.revision,
            from: r.from,
            metric,
            labels,
            count: 0,
            sum: 0,
            min: r.value,
            max: r.value,
            current: 0,
            scores: [],
            history: [],
        };
        if (!previous) {
            this.cells.set(key, c);
            this.definitions.set(family, definition);
        }
        c.count++;
        c.sum += r.value;
        c.min = Math.min(c.min, r.value);
        c.max = Math.max(c.max, r.value);
        if (metric.record && !c.scores.includes(r.value)) {
            c.scores.push(r.value);
            c.scores.sort((a, b) => (metric.record === 'low' ? a - b : b - a));
            c.scores.length = Math.min(MAX_SCORES, c.scores.length);
        }
        if (active) {
            const values = rooms ?? new Map();
            if (!values.has(r.room))
                this.gaugeValues++;
            values.set(r.room, r.value);
            this.gauges.set(key, values);
            c.current = current;
        }
        else
            c.current = metric.record ? c.scores[0] : metric.type === 'counter' ? c.sum : c.sum / c.count;
        return true;
    }
    closed(room) {
        for (const [key, rooms] of this.gauges)
            if (rooms.delete(room)) {
                this.gaugeValues--;
                const cell = this.cells.get(key);
                if (cell)
                    cell.current = [...rooms.values()].reduce((sum, n) => sum + n, 0);
                if (!rooms.size)
                    this.gauges.delete(key);
            }
    }
    sample(now) {
        if (!Number.isSafeInteger(now) || now < 0)
            throw new Error('Invalid statistics time');
        for (const c of this.cells.values()) {
            if (c.history.length && now <= c.history[c.history.length - 1][0])
                continue;
            c.history.push([now, c.current]);
            if (c.history.length > this.maxHistory)
                c.history.shift();
        }
    }
    snapshot(now) {
        if (!Number.isSafeInteger(now) || now < 0)
            throw new Error('Invalid statistics time');
        // A wall-clock correction must not produce a snapshot with history from its future.
        const captured = Math.max(now, ...[...this.cells.values()].map((c) => c.history[c.history.length - 1]?.[0] ?? 0));
        return { format: 1, instance: this.instance, captured, rows: [...this.cells.values()].map(copy) };
    }
    restore(value) {
        const snapshot = readStatistics(value);
        if (!snapshot || snapshot.instance !== this.instance || snapshot.rows.length > this.maxSeries)
            throw new Error('Invalid statistics restore');
        const cells = new Map();
        const definitions = new Map();
        for (const row of snapshot.rows) {
            const c = {
                ...copy(row),
                current: row.metric.type === 'gauge' && !row.metric.record ? 0 : row.current,
                scores: [...row.scores],
                history: row.history.slice(-this.maxHistory).map(([t, n]) => [t, n]),
            };
            cells.set(keyOf(row), c);
            definitions.set(familyOf(row), definitionOf(row.metric));
        }
        this.cells.clear();
        this.definitions.clear();
        this.gauges.clear();
        this.gaugeValues = 0;
        for (const [key, value] of cells)
            this.cells.set(key, value);
        for (const [key, value] of definitions)
            this.definitions.set(key, value);
    }
}
/** Persistence and public clients accept only bounded, coherent, anonymous snapshots. */
export function readStatistics(value) {
    if (!object(value))
        return null;
    const instance = value['instance'];
    const captured = value['captured'];
    const inputRows = value['rows'];
    if (value['format'] !== 1 ||
        typeof instance !== 'string' ||
        !INSTANCE.test(instance) ||
        typeof captured !== 'number' ||
        !Number.isSafeInteger(captured) ||
        captured < 0 ||
        !Array.isArray(inputRows) ||
        inputRows.length > MAX_SERIES)
        return null;
    const rows = [];
    const seen = new Set();
    const definitions = new Map();
    for (const raw of inputRows) {
        if (!object(raw))
            return null;
        const game = raw['game'], version = raw['version'], revision = raw['revision'], from = raw['from'];
        if (typeof game !== 'string' ||
            !GAME_ID.test(game) ||
            typeof version !== 'string' ||
            !GAME_VERSION.test(version) ||
            typeof revision !== 'string' ||
            !REVISION.test(revision) ||
            (from !== 'authority' && from !== 'host'))
            return null;
        const metric = readMetric(raw['metric']);
        if (!metric)
            return null;
        const labels = readLabels(raw['labels'], metric);
        if (!labels)
            return null;
        const count = raw['count'], sum = raw['sum'], min = raw['min'], max = raw['max'], current = raw['current'];
        if (typeof count !== 'number' ||
            !Number.isSafeInteger(count) ||
            count < 1 ||
            !finite(sum) ||
            !finite(min) ||
            !finite(max) ||
            !finite(current) ||
            min > max)
            return null;
        const average = sum / count;
        const tolerance = Number.EPSILON * Math.max(1, Math.abs(min), Math.abs(max), Math.abs(average)) * Math.max(8, count);
        if (average < min - tolerance ||
            average > max + tolerance ||
            (metric.type === 'counter' && (min < 0 || current !== sum)) ||
            (metric.type === 'histogram' && current !== average))
            return null;
        const scores = raw['scores'];
        if (!Array.isArray(scores) ||
            scores.length > MAX_SCORES ||
            scores.length > count ||
            !scores.every(finite) ||
            (!metric.record && scores.length) ||
            (metric.record &&
                (!scores.length || scores[0] !== (metric.record === 'high' ? max : min) || current !== scores[0])))
            return null;
        for (let i = 0; i < scores.length; i++) {
            const n = scores[i];
            const previous = scores[i - 1];
            if (n < min ||
                n > max ||
                (previous !== undefined && (metric.record === 'low' ? n <= previous : n >= previous)))
                return null;
        }
        const history = raw['history'];
        if (!Array.isArray(history) || history.length > MAX_HISTORY)
            return null;
        let time = -1;
        const points = [];
        for (const point of history) {
            if (!Array.isArray(point) ||
                point.length !== 2 ||
                typeof point[0] !== 'number' ||
                !Number.isSafeInteger(point[0]) ||
                point[0] <= time ||
                point[0] > captured ||
                !finite(point[1]))
                return null;
            time = point[0];
            points.push([point[0], point[1]]);
        }
        const row = {
            game,
            version,
            revision,
            from,
            metric,
            labels,
            count,
            sum,
            min,
            max,
            current,
            scores: [...scores],
            history: points,
        };
        const key = keyOf(row), family = familyOf(row), definition = definitionOf(metric);
        if (seen.has(key) || (definitions.has(family) && definitions.get(family) !== definition))
            return null;
        seen.add(key);
        definitions.set(family, definition);
        rows.push(row);
    }
    return { format: 1, instance, captured, rows };
}
