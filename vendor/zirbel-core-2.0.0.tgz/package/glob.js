/**
 * Path patterns, as manifests write them: `*` within one folder, `**` across folders, `?` one
 * character, `{a,b}` either. Paths use / and never start with it.
 */
const cache = new Map();
export function globRegExp(glob) {
    let re = cache.get(glob);
    if (re)
        return re;
    let out = '^';
    let depth = 0;
    for (let i = 0; i < glob.length; i++) {
        const c = glob[i];
        if (c === '*') {
            if (glob[i + 1] === '*') {
                // "**/" matches any number of folders, none included; "**" at the end anything.
                if (glob[i + 2] === '/') {
                    out += '(?:[^/]+/)*';
                    i += 2;
                }
                else {
                    out += '.*';
                    i += 1;
                }
            }
            else
                out += '[^/]*';
        }
        else if (c === '?')
            out += '[^/]';
        else if (c === '{') {
            out += '(?:';
            depth++;
        }
        else if (c === '}' && depth > 0) {
            out += ')';
            depth--;
        }
        else if (c === ',' && depth > 0)
            out += '|';
        else
            out += c.replace(/[.+^$()|[\]\\]/g, '\\$&');
    }
    if (depth)
        throw new Error(`"${glob}": a { without its }`);
    re = new RegExp(out + '$');
    cache.set(glob, re);
    return re;
}
export const matches = (glob, path) => globRegExp(glob).test(path);
/** Whether a pattern has any wildcard: otherwise it names one path. */
export const isGlob = (glob) => /[*?{]/.test(glob);
