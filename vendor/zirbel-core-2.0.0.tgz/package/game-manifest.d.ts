/**
 * zirbel.json: a game's manifest. See docs/game-guide.md for the fields.
 *
 * Hosts read it leniently (a game in development needs only id, version, title and players);
 * the catalog and tools/check-game.ts read it strictly.
 */
export interface Credit {
    readonly slot: string;
    readonly artist: string | null;
    readonly work: string | null;
    readonly url: string | null;
    readonly license: string | null;
}
export interface Clip {
    readonly src: string;
    readonly caption: string;
    readonly duration: number | null;
}
/**
 * One of a game's own metrics (zirbel.json "metrics"): what its authority, or its host player's
 * page, reports with net.metric(). The host adds them up over every room and serves them as
 * game_<id>_<name>, with the room's version and revision; never per player.
 */
export interface GameMetric {
    /** kills_total, round_seconds: lower case, digits and _; counters end in _total. */
    readonly name: string;
    readonly type: 'counter' | 'gauge' | 'histogram';
    /** A completed result, retained as anonymous values only. Never use for an in-progress gauge. */
    readonly record?: 'high' | 'low';
    readonly help: string;
    /** '', or one of METRIC_UNITS. */
    readonly unit: string;
    /** Histograms: upper bounds, rising. */
    readonly buckets: readonly number[];
    /** Each label with every value it may take: a fixed list, never free text. */
    readonly labels: Readonly<Record<string, readonly string[]>>;
}
export declare const METRIC_UNITS: readonly ['seconds', 'meters', 'bytes', 'ratio', 'points'];
/** A game's metrics at most, and the label combinations one may have. */
export declare const MAX_GAME_METRICS = 32;
export declare const MAX_METRIC_COMBINATIONS = 300;
/**
 * A place in a game where artists' loot can go (zirbel.json "loot.slots"): the kinds of file it
 * takes and how big they may be. An artist's enablement names a slot; the game reads what is
 * enabled in each from its host (/mp/loot/<game>/slots.json).
 */
export interface LootSlot {
    readonly id: string;
    readonly about: string;
    readonly kinds: readonly LootKind[];
    readonly max: LootMax;
    /** Items of this slot one room shows at once, and one player may hold in a round. */
    readonly perRoom: number;
    readonly perPlayer: number;
}
export interface LootMax {
    readonly bytes: number;
    readonly triangles?: number;
    /** Metres along x, y and z. */
    readonly size?: readonly [number, number, number];
    readonly pixels?: readonly [number, number];
    readonly seconds?: number;
}
/** The files loot may be, and the measures each kind's limits use. */
export declare const LOOT_KINDS: {
    readonly 'model/gltf-binary': readonly ['triangles', 'size'];
    readonly 'image/png': readonly ['pixels'];
    readonly 'image/webp': readonly ['pixels'];
    readonly 'audio/ogg': readonly ['seconds'];
    readonly 'audio/mpeg': readonly ['seconds'];
};
export type LootKind = keyof typeof LOOT_KINDS;
export declare const MAX_LOOT_SLOTS = 16;
export declare const MAX_LOOT_BYTES: number;
/** Public maturity is independent of the version number or a release's optional name. */
export declare const RELEASE_STAGES: readonly ['alpha', 'beta', 'released'];
export type ReleaseStage = (typeof RELEASE_STAGES)[number];
export declare const RELEASE_LABELS: Readonly<Record<ReleaseStage, string>>;
export declare function isReleaseStage(value: unknown): value is ReleaseStage;
export interface Manifest {
    readonly id: string;
    readonly version: string;
    readonly title: string;
    readonly stage?: ReleaseStage;
    readonly tagline: string;
    readonly players: {
        readonly min: number;
        readonly max: number;
    };
    readonly entry: string;
    readonly client?: string;
    readonly requires?: readonly string[];
    readonly authority: string | null;
    readonly runsOn: string;
    readonly orientation: 'landscape' | 'portrait' | 'any';
    readonly madeBy: {
        readonly name: string;
        readonly url: string | null;
    } | null;
    readonly source: string | null;
    readonly license: string | null;
    readonly credits: readonly Credit[];
    /** Reviewed library tracks used by this game; credited alongside all other art. */
    readonly radio?: readonly string[];
    readonly preview: {
        readonly poster: string | null;
        readonly clips: readonly Clip[];
    } | null;
    /** The back of its box on zirbel.app: up to five sentences on how it plays, as plain text. */
    readonly back: readonly string[];
    /** The creator's yes to AI agents playing it, building on it and forking it into new games. */
    readonly agents: {
        readonly play: boolean;
        readonly build: boolean;
        readonly fork: boolean;
    };
    readonly context?: {
        readonly maps: readonly {
            readonly file: string;
            readonly collection?: string;
        }[];
    };
    /** A fork: the game it was made from. */
    readonly basedOn: {
        readonly id: string;
        readonly version: string;
        readonly revision: string | null;
        readonly by: string;
    } | null;
    /** Its own metrics: [] when it declares none. */
    readonly metrics: readonly GameMetric[];
    /** Where artists' loot can go: no slots when it takes none. */
    readonly loot: {
        readonly slots: readonly LootSlot[];
    };
}
/** Game ids: also their URL path and their zirbel-net game name. */
export declare const GAME_ID: RegExp;
/** Paths a host uses itself. */
export declare const RESERVED_IDS: ReadonlySet<string>;
/** Semantic versions: 1.2.3, or 1.2.3-beta.1. */
export declare const GAME_VERSION: RegExp;
export interface ParseResult {
    readonly manifest: Manifest | null;
    readonly errors: readonly string[];
}
/** A path inside a bundle: relative, no dot segments, no hidden files, no backslashes. */
export declare function isBundlePath(p: unknown): p is string;
export declare function parseManifest(input: unknown, options?: {
    readonly strict?: boolean;
    readonly music?: (id: string) => {
        id: string;
        title: string;
        artist: string;
        license: string;
        source: string;
    } | undefined;
}): ParseResult;
/** A game's metrics as declared; a bad one is left out, and said why. */
export declare function parseMetrics(v: unknown, bad: (msg: string) => void): GameMetric[];
/** "2 to 32", "Up to 16", "1 player": for people. */
export declare function playersText(p: Manifest['players']): string;
