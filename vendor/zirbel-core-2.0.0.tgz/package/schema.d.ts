/**
 * JSON Schema, draft 2020-12, for the blocks agents compose: a small validator compiled once per
 * schema into closures, so checking a block of thousands of values takes a few milliseconds.
 *
 * It supports the keywords games need (build-interface.md 1.3) and refuses a schema that uses any
 * other, so nothing is ever silently left unchecked. Its problems name the place, the rule and the
 * field's own description, because agents read them to fix what they proposed.
 *
 * One extension, ignored by other validators: "x-zirbel-ref": "<block id>" on a string records the
 * value as a reference, which the data checks look up in that block's ids (or the asset catalogue).
 */
import { type Json } from './patch.ts';
export declare class SchemaError extends Error {
}
export interface Problem {
    /** JSON Pointer into the block: "/pieces/3/speed". */
    readonly path: string;
    readonly message: string;
}
export interface Ref {
    readonly path: string;
    readonly value: string;
    /** The block the value must be an id of, or "assets". */
    readonly target: string;
}
export interface Result {
    readonly ok: boolean;
    readonly problems: readonly Problem[];
    readonly refs: readonly Ref[];
}
/** Loads another schema file a $ref names, by its path in the game. */
export type SchemaLoader = (path: string) => unknown;
/** A compiled schema: validate() any number of documents. */
export declare class Validator {
    private readonly root;
    /**
     * Compiles a schema. `file` is its path in the game, for $refs to other schema files by relative
     * path, which `load` reads. Throws SchemaError for a schema it can't fully check.
     */
    constructor(schema: unknown, o?: {
        readonly file?: string;
        readonly load?: SchemaLoader;
    });
    /** Checks a document: its problems (at most max), and the references it makes. */
    validate(value: unknown, max?: number): Result;
}
export interface Lint {
    readonly path: string;
    readonly message: string;
}
/**
 * What a schema should have so agents can work with it (the contract): a description on every
 * property, and a minimum and a maximum on every number. For the game's creator, not a gate.
 */
export declare function lintSchema(schema: unknown): Lint[];
export type { Json };
