import { aiScope, AI_VERSION, aiLabel, allowsAi } from './ai.js';
/** Session transitions are reusable logic. A driver authenticates passes and proves seat ownership before pair(). */
export class AiSessions {
    records = new Map();
    drivers;
    constructor(drivers) {
        this.drivers = drivers;
    }
    issue(scope, pass, controller, policy) {
        scope = aiScope(scope);
        this.sweep();
        if (this.records.size >= 256 ||
            !Number.isFinite(pass.expires) ||
            pass.expires <= this.drivers.now() ||
            !allowsAi(policy, scope, 'pair', this.drivers.now()))
            throw new Error('AI use is not permitted for this scope');
        const session = {
            ...scope,
            version: AI_VERSION,
            id: this.drivers.random(),
            pass: pass.id,
            controller,
            expires: Math.min(pass.expires, this.drivers.now() + 300_000),
            epoch: 1,
            state: 'pairing',
            label: aiLabel(scope.mode),
            seq: 0,
        };
        const token = this.drivers.random(), pairUntil = Math.min(session.expires, this.drivers.now() + 30_000);
        this.records.set(session.id, { session, pairHash: this.drivers.hash(token), pairUntil });
        return { session: { ...session }, token, pair_expires: pairUntil };
    }
    get(id) {
        const r = this.records.get(id);
        return r ? { ...r.session } : null;
    }
    pair(id, token, scope, policy) {
        const r = this.records.get(id);
        if (!r ||
            r.session.state !== 'pairing' ||
            r.pairUntil <= this.drivers.now() ||
            this.drivers.hash(token) !== r.pairHash ||
            r.session.game !== scope.game ||
            r.session.room !== scope.room ||
            r.session.seat !== scope.seat ||
            !allowsAi(policy, r.session, 'pair', this.drivers.now(), r.session))
            throw new Error('Pairing expired or mismatched');
        r.pairHash = '';
        r.session.state = 'active';
        return { ...r.session };
    }
    authorize(id, policy, operation, epoch) {
        const r = this.records.get(id);
        if (!r ||
            r.session.epoch !== epoch ||
            !allowsAi(policy, r.session, operation, this.drivers.now(), r.session))
            throw new Error('Session ended or operation is not permitted');
        return { ...r.session };
    }
    observed(id) {
        const r = this.records.get(id);
        if (!r || r.session.state !== 'active')
            throw new Error('Session is not active');
        return ++r.session.seq;
    }
    end(id) {
        const r = this.records.get(id);
        if (r) {
            r.session.state = 'ended';
            r.session.epoch++;
            r.pairHash = '';
        }
    }
    revoke(pass) {
        for (const [id, r] of this.records)
            if (r.session.pass === pass)
                this.end(id);
    }
    list(game, room) {
        this.sweep();
        return [...this.records.values()]
            .map((r) => r.session)
            .filter((s) => s.game === game && s.room === room && s.state === 'active')
            .map((s) => ({ ...s }));
    }
    sweep() {
        for (const [id, r] of this.records)
            if (r.session.expires <= this.drivers.now() ||
                r.session.state === 'ended' ||
                (r.session.state === 'pairing' && r.pairUntil <= this.drivers.now()))
                this.records.delete(id);
    }
}
