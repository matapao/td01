/**
 * The catalog zirbel.app serves at /catalog.json (packages/catalog): { signed, key, signature },
 * where signed is the JSON text { format: 1, serial, issued, games: [{ id, version, url, sha256,
 * size, manifest, source }] }. Hosts check the signature before they install anything; the site
 * only shows what is listed, so it reads the signed text and checks the shape of what it uses.
 */
import { type ReleaseStage } from './game-manifest.ts';
export interface CatalogGame {
    readonly stage?: ReleaseStage;
    readonly id: string;
    readonly version: string;
    /** Bytes of the bundle a host downloads; 0 if not said. */
    readonly size: number;
    /** Its zirbel.json. */
    readonly manifest: unknown;
    /** Where the code it was packed from is, when that is public. */
    readonly source: string | null;
}
/** The games in catalog.json, in its order; null if it isn't a catalog. */
export declare function readCatalog(file: unknown): CatalogGame[] | null;
