/** Human-readable hosting sources. Creator identity and hosting platform are separate credits. */
const SOURCES = {
    'itch.io': 'itch.io',
    'pixabay.com': 'Pixabay',
    'opengameart.org': 'OpenGameArt',
    'freesound.org': 'Freesound',
    'sketchfab.com': 'Sketchfab',
    'kenney.nl': 'Kenney',
    'polyhaven.com': 'Poly Haven',
    'ambientcg.com': 'ambientCG',
    'github.com': 'GitHub',
    'fonts.google.com': 'Google Fonts',
    'bandcamp.com': 'Bandcamp',
};
export function sourceName(value) {
    if (typeof value !== 'string' || value.length > 500)
        return null;
    // Only the authority is needed for display. Keep this portable: no URL/DOM/Node dependency.
    const match = /^https:\/\/([a-z0-9.-]+)(?::([0-9]{1,5}))?(?:[/?#]|$)/i.exec(value);
    const authority = match?.[1];
    if (!authority || (match?.[2] && Number(match[2]) > 65535))
        return null;
    const host = authority.toLowerCase().replace(/^www\./, '');
    if (host.length > 253 ||
        host.split('.').some((label) => !/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(label)))
        return null;
    return (Object.entries(SOURCES).find(([domain]) => host === domain || host.endsWith('.' + domain))?.[1] ?? host);
}
