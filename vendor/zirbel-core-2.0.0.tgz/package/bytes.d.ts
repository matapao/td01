export declare const utf8: (s: string) => Uint8Array;
export declare function base64url(bytes: Uint8Array): string;
