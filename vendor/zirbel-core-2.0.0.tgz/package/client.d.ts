import type { AiScope } from './ai.ts';
import type { UiGrant } from './drivers.ts';
export interface ProviderFetch {
    (url: string, init?: {
        method?: string;
        headers?: Record<string, string>;
        body?: string;
        credentials?: 'omit';
    }): Promise<{
        ok: boolean;
        status: number;
        json(): Promise<unknown>;
    }>;
}
/** A frontend-independent client. Authentication is explicit; cookies and page redirects are unnecessary. */
export declare function providerClient(origin: string, request: ProviderFetch, token: string): {
    discovery: () => Promise<import("./provider.ts").ProviderDiscovery>;
    capabilities: (game: string) => Promise<Record<string, unknown>>;
    pair: (scope: AiScope) => Promise<UiGrant>;
    observe: (id: string) => Promise<Record<string, unknown>>;
    input: (id: string, based_on: number, input: unknown) => Promise<Record<string, unknown>>;
    stop: (id: string) => Promise<unknown>;
};
