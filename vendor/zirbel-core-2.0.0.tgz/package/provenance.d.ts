export declare function sourceName(value: unknown): string | null;
