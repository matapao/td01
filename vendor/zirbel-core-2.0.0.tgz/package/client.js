import { parseProviderDiscovery } from './provider.js';
/** A frontend-independent client. Authentication is explicit; cookies and page redirects are unnecessary. */
export function providerClient(origin, request, token) {
    const root = origin.replace(/\/$/, '') + '/mp/provider/v1';
    const call = async (path, body) => {
        const response = await request(root + path, {
            method: body ? 'POST' : 'GET',
            credentials: 'omit',
            headers: { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json' },
            ...(body ? { body: JSON.stringify(body) } : {}),
        });
        const data = await response.json();
        if (!response.ok)
            throw new Error(data.error ?? `Provider refused ${response.status}`);
        return data;
    };
    return {
        discovery: async () => parseProviderDiscovery(await call('/discovery')),
        capabilities: (game) => call('/capabilities?game=' + encodeURIComponent(game)),
        pair: (scope) => call('/ai/sessions', scope),
        observe: (id) => call('/ai/sessions/' + encodeURIComponent(id) + '/command', { op: 'observe' }),
        input: (id, based_on, input) => call('/ai/sessions/' + encodeURIComponent(id) + '/command', {
            op: 'input',
            based_on,
            input,
        }),
        stop: (id) => call('/ai/sessions/' + encodeURIComponent(id) + '/stop', {}),
    };
}
