/**
 * zirbel.json: a game's manifest. See docs/game-guide.md for the fields.
 *
 * Hosts read it leniently (a game in development needs only id, version, title and players);
 * the catalog and tools/check-game.ts read it strictly.
 */
const URL = globalThis.URL;
export const METRIC_UNITS = ['seconds', 'meters', 'bytes', 'ratio', 'points'];
/**
 * Labels a game may not use: the host adds some itself, Fly's own would overwrite others, and the
 * rest would name a person, a seat or a room. (Catalog review checks for anything else per player.)
 */
const RESERVED_LABELS = new Set([
    'game',
    'version',
    'revision',
    'from',
    'le',
    'quantile',
    'app',
    'region',
    'host',
    'instance',
    'player',
    'players',
    'seat',
    'user',
    'name',
    'id',
    'room',
    'code',
    'ip',
    'address',
    'session',
    'account',
    'peer',
    'token',
    'key',
]);
/** A game's metrics at most, and the label combinations one may have. */
export const MAX_GAME_METRICS = 32;
export const MAX_METRIC_COMBINATIONS = 300;
/** The files loot may be, and the measures each kind's limits use. */
export const LOOT_KINDS = {
    'model/gltf-binary': ['triangles', 'size'],
    'image/png': ['pixels'],
    'image/webp': ['pixels'],
    'audio/ogg': ['seconds'],
    'audio/mpeg': ['seconds'],
};
export const MAX_LOOT_SLOTS = 16;
export const MAX_LOOT_BYTES = 8 * 1024 * 1024;
/** Public maturity is independent of the version number or a release's optional name. */
export const RELEASE_STAGES = ['alpha', 'beta', 'released'];
export const RELEASE_LABELS = {
    alpha: 'Alpha',
    beta: 'Beta',
    released: 'Released',
};
export function isReleaseStage(value) {
    return value === 'alpha' || value === 'beta' || value === 'released';
}
/** Game ids: also their URL path and their zirbel-net game name. */
export const GAME_ID = /^[a-z0-9][a-z0-9-]{1,31}$/;
/** Paths a host uses itself. */
export const RESERVED_IDS = new Set(['mp', 'start', 'zirbel-net', 'catalog']);
/** Semantic versions: 1.2.3, or 1.2.3-beta.1. */
export const GAME_VERSION = /^\d{1,6}\.\d{1,6}\.\d{1,6}(?:-[0-9A-Za-z-]{1,20}(?:\.[0-9A-Za-z-]{1,20}){0,3})?$/;
const LICENSE = /^[A-Za-z0-9.+-]{1,40}(?: (?:OR|AND|WITH) [A-Za-z0-9.+-]{1,40})*$/;
/** Characters that don't belong in text people read: controls, invisible formatting, private use, line separators. */
const HIDDEN = /[\p{Cc}\p{Cf}\p{Co}\p{Cs}\p{Zl}\p{Zp}]/u;
const REVISION = /^r[\w.-]{1,40}$/;
/** A path inside a bundle: relative, no dot segments, no hidden files, no backslashes. */
export function isBundlePath(p) {
    return (typeof p === 'string' &&
        p.length > 0 &&
        p.length <= 240 &&
        !p.startsWith('/') &&
        !p.includes('\\') &&
        !p.includes('\0') &&
        p.split('/').every((s) => s !== '' && !s.startsWith('.')));
}
function isHttpsUrl(u) {
    if (typeof u !== 'string' || u.length > 500)
        return false;
    try {
        return new URL(u).protocol === 'https:';
    }
    catch {
        return false;
    }
}
export function parseManifest(input, options = {}) {
    const strict = options.strict ?? false;
    const errors = [];
    const bad = (msg) => void errors.push(msg);
    if (typeof input !== 'object' || input === null || Array.isArray(input))
        return { manifest: null, errors: ['zirbel.json must be an object'] };
    const m = input;
    const text = (key, max, required) => {
        const v = m[key];
        if (v === undefined || v === null) {
            if (required)
                bad(`${key} is required`);
            return '';
        }
        if (typeof v !== 'string' || v.length > max)
            bad(`${key} must be a string of at most ${max} characters`);
        return typeof v === 'string' ? v.slice(0, max) : '';
    };
    const id = text('id', 32, true);
    if (id && !GAME_ID.test(id))
        bad('id must be 2 to 32 characters of a-z, 0-9 and -, starting with a letter or digit');
    if (RESERVED_IDS.has(id))
        bad(`id "${id}" is reserved`);
    const version = text('version', 60, true);
    if (version && !GAME_VERSION.test(version))
        bad('version must look like 1.2.3');
    const title = text('title', 60, true);
    const stage = m['stage'];
    if (stage !== undefined && !isReleaseStage(stage))
        bad('stage must be alpha, beta or released');
    const tagline = text('tagline', 160, false);
    const runsOn = text('runsOn', 60, false);
    const p = m['players'];
    let players = { min: 1, max: 32 };
    if (typeof p !== 'object' || p === null)
        bad('players must be { "min": n, "max": n }');
    else {
        const { min, max } = p;
        if (!Number.isInteger(min) ||
            !Number.isInteger(max) ||
            min < 1 ||
            max < min ||
            max > 253) {
            bad('players.min and players.max must be whole numbers, 1 <= min <= max <= 253');
        }
        else
            players = { min: min, max: max };
    }
    const entry = m['entry'] === undefined ? 'index.html' : m['entry'];
    const client = m['client'];
    if (client !== undefined && (!isBundlePath(client) || !/\.m?js$/.test(client)))
        bad('client must name the portable JavaScript mount module');
    const requires = m['requires'];
    if (requires !== undefined &&
        (!Array.isArray(requires) ||
            requires.length > 32 ||
            requires.some((value) => typeof value !== 'string' || !/^[a-z][a-zA-Z0-9./-]{0,63}$/.test(value))))
        bad('requires must list supported capability names');
    if (!isBundlePath(entry) || !/\.html?$/i.test(entry))
        bad('entry must be a relative path to an .html file');
    const authority = m['authority'] ?? null;
    if (authority !== null && (!isBundlePath(authority) || !/\.m?js$/.test(authority)))
        bad('authority must be a relative path to a .js module');
    const orientation = m['orientation'] ?? 'any';
    if (orientation !== 'landscape' && orientation !== 'portrait' && orientation !== 'any')
        bad('orientation must be landscape, portrait or any');
    let madeBy = null;
    const mb = m['madeBy'];
    if (mb !== undefined && mb !== null) {
        const { name, url } = mb;
        if (typeof name !== 'string' || !name || name.length > 80)
            bad('madeBy.name must be a string of at most 80 characters');
        if (url !== undefined && url !== null && !isHttpsUrl(url))
            bad('madeBy.url must be an https URL');
        madeBy = { name: typeof name === 'string' ? name : '', url: isHttpsUrl(url) ? url : null };
    }
    else if (strict)
        bad('madeBy is required');
    // Where the code lives, when it is public: the catalog lists games whose code isn't, too.
    const source = m['source'] ?? null;
    if (source !== null && !isHttpsUrl(source))
        bad('source must be an https URL');
    const license = m['license'] ?? null;
    if (license !== null && (typeof license !== 'string' || !LICENSE.test(license)))
        bad('license must be an SPDX license id, like MIT');
    else if (license === null && strict)
        bad('license is required');
    const credits = [];
    const cr = m['credits'] ?? [];
    if (!Array.isArray(cr) || cr.length > 40)
        bad('credits must be a list of at most 40 entries');
    else {
        cr.forEach((c, i) => {
            const e = (c ?? {});
            const opt = (k, max) => {
                const v = e[k];
                if (v === null || v === undefined)
                    return null;
                if (typeof v !== 'string' || v.length > max) {
                    bad(`credits[${i}].${k} must be a string or null`);
                    return null;
                }
                return v;
            };
            const slot = e['slot'];
            if (typeof slot !== 'string' || !slot || slot.length > 40)
                bad(`credits[${i}].slot is required`);
            const url = opt('url', 500);
            if (url !== null && !isHttpsUrl(url))
                bad(`credits[${i}].url must be an https URL`);
            credits.push({
                slot: typeof slot === 'string' ? slot : '',
                artist: opt('artist', 80),
                work: opt('work', 120),
                url,
                license: opt('license', 60),
            });
        });
    }
    const radio = [];
    if (m['radio'] !== undefined) {
        const tracks = m['radio'];
        if (!Array.isArray(tracks) || tracks.length > 30)
            bad('radio must be a list of at most 30 library track ids');
        else
            for (const id of tracks) {
                const track = typeof id === 'string' ? options.music?.(id) : undefined;
                if (typeof id !== 'string' || !/^[a-zA-Z0-9_-]{1,128}$/.test(id))
                    bad('radio: invalid track id');
                else if (!track) {
                    if (options.music)
                        bad(`radio: unknown music track ${String(id)}`);
                    else if (!radio.includes(id))
                        radio.push(id);
                }
                else if (!radio.includes(track.id)) {
                    radio.push(track.id);
                    const credit = {
                        slot: 'Music',
                        artist: track.artist,
                        work: track.title,
                        license: track.license,
                        url: track.source,
                    };
                    if (!credits.some((c) => c.work === credit.work && c.artist === credit.artist && c.url === credit.url))
                        credits.push(credit);
                }
            }
    }
    let preview = null;
    const pv = m['preview'];
    if (pv !== undefined && pv !== null) {
        // In the catalog, preview media live outside the bundle: absolute https URLs. A game in this
        // repository may point at files in its preview/ folder instead.
        const media = (u) => isHttpsUrl(u) || (!strict && isBundlePath(u));
        const { poster, clips } = pv;
        if (poster !== undefined && poster !== null && !media(poster))
            bad('preview.poster must be an https URL');
        const list = [];
        if (clips !== undefined && (!Array.isArray(clips) || clips.length > 3))
            bad('preview.clips must be a list of at most 3 clips');
        else
            for (const [i, c] of (clips ?? []).entries()) {
                const { src, caption, duration } = (c ?? {});
                if (!media(src))
                    bad(`preview.clips[${i}].src must be an https URL`);
                if (caption !== undefined && (typeof caption !== 'string' || caption.length > 40))
                    bad(`preview.clips[${i}].caption must be a short string`);
                if (duration !== undefined && (typeof duration !== 'number' || !(duration > 0 && duration < 30)))
                    bad(`preview.clips[${i}].duration must be seconds`);
                list.push({
                    src: String(src),
                    caption: typeof caption === 'string' ? caption : '',
                    duration: typeof duration === 'number' ? duration : null,
                });
            }
        preview = { poster: typeof poster === 'string' ? poster : null, clips: list };
    }
    const back = [];
    const bk = m['back'] ?? [];
    if (!Array.isArray(bk) || bk.length > 5)
        bad('back must be a list of at most 5 sentences');
    else
        bk.forEach((t, i) => {
            if (typeof t !== 'string' || !t.trim() || t.length > 200 || HIDDEN.test(t))
                bad(`back[${i}] must be a sentence of at most 200 characters, in plain text`);
            else
                back.push(t.trim());
        });
    const ag = m['agents'] ?? {};
    const yes = (k) => {
        const v = ag[k];
        if (v !== undefined && typeof v !== 'boolean')
            bad(`agents.${k} must be true or false`);
        return v === true;
    };
    const agents = typeof ag === 'object' && ag !== null && !Array.isArray(ag)
        ? { play: yes('play'), build: yes('build'), fork: yes('fork') }
        : (bad('agents must be { "play", "build", "fork" }'), { play: false, build: false, fork: false });
    let basedOn = null;
    const bo = m['basedOn'];
    if (bo !== undefined && bo !== null) {
        const { id: from, version: at, revision, by, } = bo;
        if (typeof from !== 'string' || !GAME_ID.test(from))
            bad('basedOn.id must be a game id');
        if (typeof at !== 'string' || !GAME_VERSION.test(at))
            bad('basedOn.version must look like 1.2.3');
        if (revision !== undefined &&
            revision !== null &&
            (typeof revision !== 'string' || !REVISION.test(revision)))
            bad('basedOn.revision must be a revision id');
        if (typeof by !== 'string' || !by.trim() || by.length > 80 || HIDDEN.test(by))
            bad('basedOn.by must be plain text of at most 80 characters');
        basedOn = {
            id: String(from),
            version: String(at),
            revision: typeof revision === 'string' ? revision : null,
            by: typeof by === 'string' ? by.trim() : '',
        };
    }
    // A host leaves out metrics it can't take rather than the game; the catalog refuses them.
    const metricErrors = [];
    const metrics = parseMetrics(m['metrics'], (msg) => void metricErrors.push(msg));
    if (strict)
        errors.push(...metricErrors);
    const lootErrors = [];
    const slots = parseLootSlots(m['loot'], (msg) => void lootErrors.push(msg));
    if (strict)
        errors.push(...lootErrors);
    let context;
    if (m['context'] !== undefined) {
        const maps = m['context']?.maps;
        if (!Array.isArray(maps) || maps.length > 8)
            bad('context.maps must name at most eight public documents');
        else {
            const sources = [];
            for (const entry of maps) {
                const r = entry;
                if (!r ||
                    !isBundlePath(r.file) ||
                    !r.file.endsWith('.json') ||
                    (r.collection !== undefined &&
                        (typeof r.collection !== 'string' || !/^[a-zA-Z][\w-]{0,63}$/.test(r.collection))))
                    bad('context map needs a JSON bundle path and optional collection key');
                else
                    sources.push({
                        file: r.file,
                        ...(typeof r.collection === 'string' ? { collection: r.collection } : {}),
                    });
            }
            context = { maps: sources };
        }
    }
    if (errors.length)
        return { manifest: null, errors };
    return {
        manifest: {
            id,
            version,
            title,
            ...(isReleaseStage(stage) ? { stage } : {}),
            tagline,
            players,
            entry: entry,
            ...(typeof client === 'string' ? { client } : {}),
            ...(Array.isArray(requires) ? { requires: requires } : {}),
            authority: authority,
            runsOn,
            orientation: orientation,
            madeBy,
            source: source,
            license: license,
            credits,
            ...(radio.length ? { radio } : {}),
            ...(context ? { context } : {}),
            preview,
            back,
            agents,
            basedOn,
            metrics,
            loot: { slots },
        },
        errors,
    };
}
const METRIC_NAME = /^[a-z][a-z0-9_]{1,47}$/;
const METRIC_LABEL = /^[a-z][a-z0-9_]{0,31}$/;
const METRIC_VALUE = /^[a-z0-9][a-z0-9_.-]{0,31}$/;
/** A game's metrics as declared; a bad one is left out, and said why. */
export function parseMetrics(v, bad) {
    if (v === undefined || v === null)
        return [];
    if (!Array.isArray(v) || v.length > MAX_GAME_METRICS) {
        bad(`metrics must be a list of at most ${MAX_GAME_METRICS}`);
        return [];
    }
    const out = [];
    const names = new Set();
    v.forEach((x, i) => {
        const e = (x ?? {});
        const at = `metrics[${i}]`;
        const name = e['name'], type = e['type'], help = e['help'], unit = e['unit'] ?? '', labels = e['labels'] ?? {};
        if (typeof name !== 'string' || !METRIC_NAME.test(name))
            return bad(`${at}.name must be 2 to 48 characters of a-z, 0-9 and _`);
        if (names.has(name))
            return bad(`${at}: ${name} is declared twice`);
        if (type !== 'counter' && type !== 'gauge' && type !== 'histogram')
            return bad(`${at}.type must be counter, gauge or histogram`);
        const record = e['record'];
        if (record !== undefined && (type !== 'gauge' || (record !== 'high' && record !== 'low')))
            return bad(`${at}.record must be high or low on a completed-result gauge`);
        if (type === 'counter' && !name.endsWith('_total'))
            return bad(`${at}: a counter's name ends in _total`);
        if (type !== 'counter' && /_(?:total|bucket|sum|count)$/.test(name))
            return bad(`${at}: only counters' names end in _total (and none in _bucket, _sum or _count)`);
        if (typeof help !== 'string' || !help.trim() || help.length > 160 || /[\n\r]/.test(help))
            return bad(`${at}.help must be one line of at most 160 characters`);
        if (unit !== '' && !METRIC_UNITS.includes(unit))
            return bad(`${at}.unit must be one of ${METRIC_UNITS.join(', ')}`);
        let buckets = [];
        if (type === 'histogram') {
            const b = e['buckets'];
            if (!Array.isArray(b) ||
                !b.length ||
                b.length > 15 ||
                !b.every((n, j) => typeof n === 'number' && Number.isFinite(n) && (j === 0 || n > b[j - 1]))) {
                return bad(`${at}.buckets must be 1 to 15 rising numbers`);
            }
            buckets = b;
        }
        else if (e['buckets'] !== undefined)
            return bad(`${at}: only histograms have buckets`);
        if (typeof labels !== 'object' || Array.isArray(labels))
            return bad(`${at}.labels must map each label to its values`);
        const entries = Object.entries(labels);
        if (entries.length > 3)
            return bad(`${at}: 3 labels at most`);
        let combinations = 1;
        for (const [k, vals] of entries) {
            if (!METRIC_LABEL.test(k) || RESERVED_LABELS.has(k))
                return bad(`${at}.labels.${k}: not a label name a game may use`);
            if (!Array.isArray(vals) ||
                !vals.length ||
                vals.length > 24 ||
                new Set(vals).size !== vals.length ||
                !vals.every((x) => typeof x === 'string' && METRIC_VALUE.test(x))) {
                return bad(`${at}.labels.${k} must list 1 to 24 different values of a-z, 0-9, _ . and -`);
            }
            combinations *= vals.length;
        }
        if (combinations > MAX_METRIC_COMBINATIONS)
            return bad(`${at}: its labels make ${combinations} combinations, over ${MAX_METRIC_COMBINATIONS}`);
        names.add(name);
        out.push({
            name,
            type,
            ...(record === 'high' || record === 'low' ? { record } : {}),
            help: help.trim(),
            unit: unit,
            buckets,
            labels: labels,
        });
    });
    return out;
}
const SLOT_ID = /^[a-z0-9][a-z0-9-]{1,31}$/;
/** A game's loot slots as declared; a bad one is left out, and said why. */
function parseLootSlots(v, bad) {
    if (v === undefined || v === null)
        return [];
    const list = typeof v === 'object' && !Array.isArray(v) ? v.slots : undefined;
    if (!Array.isArray(list) || list.length > MAX_LOOT_SLOTS) {
        bad(`loot.slots must be a list of at most ${MAX_LOOT_SLOTS}`);
        return [];
    }
    const out = [];
    const count = (x, max) => Number.isInteger(x) && x >= 1 && x <= max;
    const dims = (x, n, max) => Array.isArray(x) && x.length === n && x.every((d) => typeof d === 'number' && d > 0 && d <= max);
    list.forEach((x, i) => {
        const e = (x ?? {});
        const at = `loot.slots[${i}]`;
        const id = e['id'], about = e['about'], kinds = e['kinds'], max = (e['max'] ?? {});
        const perRoom = e['perRoom'] ?? 1, perPlayer = e['perPlayer'] ?? 1;
        if (typeof id !== 'string' || !SLOT_ID.test(id))
            return bad(`${at}.id must be 2 to 32 characters of a-z, 0-9 and -`);
        if (out.some((s) => s.id === id))
            return bad(`${at}: ${id} is declared twice`);
        if (typeof about !== 'string' || !about.trim() || about.length > 160 || HIDDEN.test(about))
            return bad(`${at}.about must be plain text of at most 160 characters`);
        if (!Array.isArray(kinds) ||
            !kinds.length ||
            new Set(kinds).size !== kinds.length ||
            !kinds.every((k) => typeof k === 'string' && k in LOOT_KINDS)) {
            return bad(`${at}.kinds must list some of ${Object.keys(LOOT_KINDS).join(', ')}`);
        }
        if (!count(max['bytes'], MAX_LOOT_BYTES))
            return bad(`${at}.max.bytes must be a whole number up to ${MAX_LOOT_BYTES}`);
        if (max['triangles'] !== undefined && !count(max['triangles'], 1_000_000))
            return bad(`${at}.max.triangles must be a whole number up to 1000000`);
        if (max['size'] !== undefined && !dims(max['size'], 3, 1000))
            return bad(`${at}.max.size must be [x, y, z] in metres`);
        if (max['pixels'] !== undefined &&
            !(dims(max['pixels'], 2, 8192) && max['pixels'].every(Number.isInteger)))
            return bad(`${at}.max.pixels must be [width, height]`);
        if (max['seconds'] !== undefined &&
            !(typeof max['seconds'] === 'number' && max['seconds'] > 0 && max['seconds'] <= 600))
            return bad(`${at}.max.seconds must be up to 600`);
        if (!count(perRoom, 64) || !count(perPlayer, 16))
            return bad(`${at}: perRoom is 1 to 64 and perPlayer 1 to 16`);
        const lim = {
            bytes: max['bytes'],
            ...(max['triangles'] !== undefined ? { triangles: max['triangles'] } : {}),
            ...(max['size'] !== undefined ? { size: max['size'] } : {}),
            ...(max['pixels'] !== undefined ? { pixels: max['pixels'] } : {}),
            ...(max['seconds'] !== undefined ? { seconds: max['seconds'] } : {}),
        };
        out.push({ id, about: about.trim(), kinds: kinds, max: lim, perRoom, perPlayer });
    });
    return out;
}
/** "2 to 32", "Up to 16", "1 player": for people. */
export function playersText(p) {
    if (p.min === p.max)
        return p.max === 1 ? '1 player' : `${p.max} players`;
    return p.min <= 1 ? `Up to ${p.max}` : `${p.min} to ${p.max}`;
}
