/**
 * SHA-256 that answers at once (FIPS 180-4), for Merkle trees and ids in a page as in Node. Node's
 * own code swaps in node:crypto with useSha256().
 */
/** The JavaScript implementation itself, whatever useSha256() swapped in. */
export declare function jsSha256(data: Uint8Array): Uint8Array<ArrayBuffer>;
export declare const sha256: (data: Uint8Array) => Uint8Array<ArrayBuffer>;
/** Another implementation of the same function (node:crypto's, in Node). */
export declare function useSha256(f: (data: Uint8Array) => Uint8Array<ArrayBuffer>): void;
