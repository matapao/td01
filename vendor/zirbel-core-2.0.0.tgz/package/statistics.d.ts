/** Anonymous statistics. Room keys exist only while combining active gauges, never in snapshots. */
import { type GameMetric } from './game-manifest.ts';
export interface Statistic {
    readonly game: string;
    readonly version: string;
    readonly revision: string;
    readonly from: 'authority' | 'host';
    readonly metric: GameMetric;
    readonly labels: Readonly<Record<string, string>>;
    readonly count: number;
    readonly sum: number;
    readonly min: number;
    readonly max: number;
    readonly current: number;
    readonly scores: readonly number[];
    readonly history: readonly (readonly [number, number])[];
}
export interface StatisticsSnapshot {
    readonly format: 1;
    readonly instance: string;
    readonly captured: number;
    readonly rows: readonly Statistic[];
}
export interface MetricReport {
    readonly game: string;
    readonly version: string;
    readonly revision: string;
    readonly room: string;
    readonly from: 'authority' | 'host';
    readonly metric: GameMetric;
    readonly labels: Readonly<Record<string, string>>;
    readonly value: number;
}
export interface StatisticsLimits {
    readonly maxSeries?: number;
    readonly maxHistory?: number;
    readonly maxRoomsPerSeries?: number;
    readonly maxGaugeValues?: number;
}
export declare class GameStatistics {
    private readonly cells;
    private readonly definitions;
    private readonly gauges;
    private gaugeValues;
    private readonly maxSeries;
    private readonly maxHistory;
    private readonly maxRoomsPerSeries;
    private readonly maxGaugeValues;
    readonly instance: string;
    constructor(instance: string, limits?: StatisticsLimits);
    report(r: MetricReport): boolean;
    closed(room: string): void;
    sample(now: number): void;
    snapshot(now: number): StatisticsSnapshot;
    restore(value: StatisticsSnapshot): void;
}
/** Persistence and public clients accept only bounded, coherent, anonymous snapshots. */
export declare function readStatistics(value: unknown): StatisticsSnapshot | null;
