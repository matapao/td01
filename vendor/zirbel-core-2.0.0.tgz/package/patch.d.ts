/**
 * JSON Pointer (RFC 6901) and JSON Patch (RFC 6902): how agents change a block without sending all
 * of it. A patch applies as a whole or not at all, and the document it is given is never changed.
 */
export type Json = null | boolean | number | string | Json[] | {
    [key: string]: Json;
};
export type PatchOp = {
    readonly op: 'add' | 'replace' | 'test';
    readonly path: string;
    readonly value: Json;
} | {
    readonly op: 'remove';
    readonly path: string;
} | {
    readonly op: 'move' | 'copy';
    readonly path: string;
    readonly from: string;
};
export declare class PatchError extends Error {
}
/** At most this many operations in one patch. */
export declare const MAX_OPS = 2000;
/** "/a/b~1c" → ["a", "b/c"]. Throws on a pointer that doesn't start with "/" (but "" is the whole document). */
export declare function parsePointer(pointer: string): string[];
export declare function formatPointer(parts: readonly (string | number)[]): string;
/** What the pointer points at, or undefined. */
export declare function getPointer(doc: Json, pointer: string): Json | undefined;
/** RFC 6902 equality: same type and value; objects by their keys, arrays in order. */
export declare function jsonEqual(a: unknown, b: unknown): boolean;
/** Checks that a value is a list of patch operations, and returns it typed. */
export declare function parsePatch(input: unknown): PatchOp[];
/** The document with the patch applied. Throws PatchError (naming the operation) if any operation can't apply. */
export declare function applyPatch(doc: Json, ops: readonly PatchOp[]): Json;
/**
 * The JSON text for a changed block, written the way the file was: each object and array on one
 * line or over several as it was before (new ones like their neighbours), the same indentation
 * and spacing, the same final newline. A diff then shows what changed and nothing else.
 */
export declare function formatLike(original: string, value: Json): string;
/**
 * A JSON Patch from a to b: what changed, by place. Array items are changed in place where they
 * kept their index, added and removed where the array grew or shrank, and guarded with "test" so
 * the patch applied onto a document where items moved fails instead of changing the wrong one.
 */
export declare function diffJson(a: Json, b: Json, pointer?: string): PatchOp[];
