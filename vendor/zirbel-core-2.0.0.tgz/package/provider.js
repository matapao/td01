/** Portable, descriptive provider inventory. Discovery never grants authority to invoke an operation. */
import { jsonEqual } from './patch.js';
import { Validator } from './schema.js';
import { utf8 } from './bytes.js';
export const PROVIDER_DISCOVERY_VERSION = 'zirbel.provider/discovery-v1';
export const PROVIDER_CONTRACT_LIMITS = Object.freeze({
    capabilities: 128,
    scopes: 32,
    identifierLength: 160,
    reasonLength: 512,
    schemaBytes: 32_768,
    schemaDepth: 16,
    documentBytes: 1_048_576,
    documentNodes: 32_768,
});
export class ProviderContractError extends Error {
}
function reject(path, message) {
    throw new ProviderContractError(`${path}: ${message}`);
}
function isRecord(value) {
    return typeof value === 'object' && value !== null && !Array.isArray(value);
}
function record(value, path) {
    if (!isRecord(value))
        reject(path, 'expected an object');
    return value;
}
function fields(value, keys, path) {
    const result = record(value, path);
    if (Object.keys(result).some((key) => !keys.includes(key)))
        reject(path, 'unknown field');
    return result;
}
function text(value, path, max = PROVIDER_CONTRACT_LIMITS.identifierLength) {
    if (typeof value !== 'string' || !value.length || value.length > max)
        reject(path, `expected a nonempty string of at most ${max} characters`);
    return value;
}
function identifier(value, path) {
    const result = text(value, path);
    if (!/^[a-z][a-z0-9-]*(?:[./][a-z0-9][a-z0-9_-]*)+$/.test(result))
        reject(path, 'expected a namespaced identifier');
    return result;
}
function choice(value, choices, path) {
    for (const allowed of choices)
        if (value === allowed)
            return allowed;
    return reject(path, 'unsupported value');
}
function boolean(value, path) {
    if (typeof value !== 'boolean')
        reject(path, 'expected a boolean');
    return value;
}
function list(value, path, max) {
    if (!Array.isArray(value) || value.length > max)
        reject(path, `expected at most ${max} entries`);
    return value;
}
function bound(value, path) {
    if (value === null)
        return null;
    if (typeof value !== 'number' || !Number.isSafeInteger(value) || value < 1)
        reject(path, 'expected a positive safe integer or null');
    return value;
}
/** Reject cycles, non-JSON values, accessors and excess work before schema compilation. */
function json(value, path, maxBytes, maxDepth) {
    const ancestors = new Set();
    let nodes = 0;
    let bytes = 0;
    const charge = (amount) => {
        bytes += amount;
        if (bytes > maxBytes)
            reject(path, `JSON exceeds ${maxBytes} bytes`);
    };
    const stringBytes = (s) => {
        if (s.length > maxBytes)
            reject(path, `JSON exceeds ${maxBytes} bytes`);
        return utf8(JSON.stringify(s)).length;
    };
    const visit = (entry, depth) => {
        if (++nodes > PROVIDER_CONTRACT_LIMITS.documentNodes || depth > maxDepth)
            reject(path, 'JSON exceeds structural limits');
        if (entry === null || typeof entry === 'boolean') {
            charge(entry === null ? 4 : entry ? 4 : 5);
            return entry;
        }
        if (typeof entry === 'string') {
            charge(stringBytes(entry));
            return entry;
        }
        if (typeof entry === 'number' && Number.isFinite(entry)) {
            charge(String(entry).length);
            return entry;
        }
        if (typeof entry !== 'object' || entry === null)
            reject(path, 'expected finite JSON values');
        if (ancestors.has(entry))
            reject(path, 'cyclic JSON');
        ancestors.add(entry);
        const descriptors = Object.getOwnPropertyDescriptors(entry);
        const entries = [];
        const array = Array.isArray(entry);
        if (!array && Object.getPrototypeOf(entry) !== Object.prototype && Object.getPrototypeOf(entry) !== null)
            reject(path, 'expected plain JSON objects');
        const keys = Object.keys(entry);
        if (array && keys.length !== entry.length)
            reject(path, 'expected dense JSON arrays');
        charge(2 + Math.max(0, keys.length - 1));
        for (const key of keys) {
            const descriptor = descriptors[key];
            if (!descriptor || !('value' in descriptor))
                reject(path, 'JSON accessors are unsupported');
            const next = descriptor.value;
            if (!array)
                charge(stringBytes(key) + 1);
            entries.push([key, visit(next, depth + 1)]);
        }
        ancestors.delete(entry);
        if (array) {
            if (keys.some((key, index) => key !== String(index)))
                reject(path, 'expected JSON array indexes');
            return entries.map((entry) => entry[1]);
        }
        return Object.fromEntries(entries);
    };
    return visit(value, 0);
}
const SCHEMA_TYPES = ['null', 'boolean', 'object', 'array', 'number', 'string', 'integer'];
const SCHEMA_COUNTS = new Set([
    'minItems',
    'maxItems',
    'minContains',
    'maxContains',
    'minLength',
    'maxLength',
    'minProperties',
    'maxProperties',
]);
const SCHEMA_NUMBERS = new Set(['minimum', 'maximum', 'exclusiveMinimum', 'exclusiveMaximum', 'multipleOf']);
const SCHEMA_SINGLE = new Set([
    'additionalProperties',
    'propertyNames',
    'items',
    'contains',
    'not',
    'if',
    'then',
    'else',
]);
const SCHEMA_LIST = new Set(['prefixItems', 'allOf', 'anyOf', 'oneOf']);
const SCHEMA_MAP = new Set(['properties', 'dependentSchemas']);
const SCHEMA_TEXT = new Set(['title', 'description', '$comment', 'contentMediaType', 'contentEncoding']);
const SCHEMA_BOOLEAN = new Set(['uniqueItems', 'deprecated', 'readOnly', 'writeOnly']);
function stringList(value, path, max) {
    const strings = list(value, path, max).map((entry) => text(entry, path));
    if (new Set(strings).size !== strings.length)
        reject(path, 'duplicate entries');
    return strings;
}
/**
 * v1 accepts self-contained schemas supported by Validator, excluding regex and references.
 * Untrusted regex and recursive references can cause unbounded validation work; adapters use
 * explicit bounded properties and compose richer local validation in the authoritative owner.
 */
function schema(value, path) {
    const result = json(value, path, PROVIDER_CONTRACT_LIMITS.schemaBytes, PROVIDER_CONTRACT_LIMITS.schemaDepth);
    const check = (entry) => {
        if (typeof entry === 'boolean')
            return;
        const definition = record(entry, path);
        for (const [key, child] of Object.entries(definition)) {
            if (SCHEMA_COUNTS.has(key)) {
                if (typeof child !== 'number' || !Number.isSafeInteger(child) || child < 0)
                    reject(path, `${key} must be a nonnegative safe integer`);
            }
            else if (SCHEMA_NUMBERS.has(key)) {
                if (typeof child !== 'number' || (key === 'multipleOf' && child <= 0))
                    reject(path, `${key} must be a valid number`);
            }
            else if (SCHEMA_SINGLE.has(key))
                check(child);
            else if (SCHEMA_LIST.has(key)) {
                const children = list(child, path, 128);
                if (key !== 'prefixItems' && !children.length)
                    reject(path, `${key} must be nonempty`);
                children.forEach(check);
            }
            else if (SCHEMA_MAP.has(key))
                Object.values(record(child, path)).forEach(check);
            else if (SCHEMA_TEXT.has(key)) {
                if (typeof child !== 'string')
                    reject(path, `${key} must be a string`);
            }
            else if (SCHEMA_BOOLEAN.has(key))
                boolean(child, path);
            else if (key === '$schema') {
                if (child !== 'https://json-schema.org/draft/2020-12/schema')
                    reject(path, 'unsupported schema draft');
            }
            else if (key === 'type') {
                if (Array.isArray(child)) {
                    const types = stringList(child, path, SCHEMA_TYPES.length);
                    if (!types.length)
                        reject(path, 'type must be nonempty');
                    types.forEach((type) => choice(type, SCHEMA_TYPES, path));
                }
                else
                    choice(child, SCHEMA_TYPES, path);
            }
            else if (key === 'required')
                stringList(child, path, 128);
            else if (key === 'dependentRequired') {
                for (const names of Object.values(record(child, path)))
                    stringList(names, path, 128);
            }
            else if (key === 'enum') {
                const options = list(child, path, 128);
                if (!options.length)
                    reject(path, 'enum must be nonempty');
                if (options.some((option, index) => options.slice(0, index).some((earlier) => jsonEqual(option, earlier))))
                    reject(path, 'enum contains duplicate values');
            }
            else if (key === 'examples')
                list(child, path, 128);
            else if (key !== 'const' && key !== 'default')
                reject(path, `unsupported schema keyword ${key}`);
        }
    };
    check(result);
    try {
        new Validator(result);
    }
    catch {
        reject(path, 'invalid schema definition');
    }
    return result;
}
/** Decode and copy an untrusted capability. Supported availability is never an authorization result. */
export function parseCapabilityDescriptor(value) {
    const raw = fields(json(value, 'capability', PROVIDER_CONTRACT_LIMITS.documentBytes, 24), [
        'id',
        'version',
        'availability',
        'inputSchema',
        'outputSchema',
        'authorization',
        'effects',
        'execution',
        'delivery',
        'limits',
        'policy',
    ], 'capability');
    const version = text(raw['version'], 'version');
    if (!/^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(?:-[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/.test(version))
        reject('version', 'expected a semantic version');
    const prerelease = version.split('+')[0]?.split('-').slice(1).join('-');
    if (prerelease?.split('.').some((part) => /^0[0-9]+$/.test(part)))
        reject('version', 'numeric prerelease identifiers cannot have leading zeros');
    const available = fields(raw['availability'], ['status', 'reason'], 'availability');
    const status = choice(available['status'], ['supported', 'unsupported', 'manual', 'approval-required'], 'availability.status');
    const authorization = fields(raw['authorization'], ['required', 'scopes'], 'authorization');
    const scopes = stringList(authorization['scopes'], 'authorization.scopes', PROVIDER_CONTRACT_LIMITS.scopes);
    const required = boolean(authorization['required'], 'authorization.required');
    if (scopes.length && !required)
        reject('authorization', 'scopes require authorization');
    const effects = list(raw['effects'], 'effects', 4).map((effect) => choice(effect, ['read', 'write', 'execute', 'publish'], 'effects'));
    if (new Set(effects).size !== effects.length)
        reject('effects', 'duplicate entries');
    const execution = fields(raw['execution'], ['environment'], 'execution');
    const delivery = fields(raw['delivery'], ['mode', 'ordering', 'replay'], 'delivery');
    const limits = fields(raw['limits'], ['maxInputBytes', 'maxOutputBytes', 'timeoutMs'], 'limits');
    return {
        id: identifier(raw['id'], 'id'),
        version,
        availability: {
            status,
            ...(available['reason'] === undefined
                ? {}
                : {
                    reason: text(available['reason'], 'availability.reason', PROVIDER_CONTRACT_LIMITS.reasonLength),
                }),
        },
        inputSchema: schema(raw['inputSchema'], 'inputSchema'),
        outputSchema: schema(raw['outputSchema'], 'outputSchema'),
        authorization: { required, scopes },
        effects,
        execution: {
            environment: choice(execution['environment'], ['portable', 'browser', 'server', 'native', 'external', 'manual'], 'execution.environment'),
        },
        delivery: {
            mode: choice(delivery['mode'], ['request-response', 'stream', 'subscription', 'job'], 'delivery.mode'),
            ordering: choice(delivery['ordering'], ['none', 'per-resource', 'total'], 'delivery.ordering'),
            replay: boolean(delivery['replay'], 'delivery.replay'),
        },
        limits: {
            maxInputBytes: bound(limits['maxInputBytes'], 'limits.maxInputBytes'),
            maxOutputBytes: bound(limits['maxOutputBytes'], 'limits.maxOutputBytes'),
            timeoutMs: bound(limits['timeoutMs'], 'limits.timeoutMs'),
        },
        policy: identifier(raw['policy'], 'policy'),
    };
}
/** Validates the envelope version, rejects duplicate identities and returns deterministic ID ordering. */
export function parseProviderDiscovery(value) {
    const raw = fields(json(value, 'discovery', PROVIDER_CONTRACT_LIMITS.documentBytes, 28), ['version', 'provider', 'capabilities'], 'discovery');
    if (raw['version'] !== PROVIDER_DISCOVERY_VERSION)
        reject('version', 'unsupported discovery version');
    const capabilities = list(raw['capabilities'], 'capabilities', PROVIDER_CONTRACT_LIMITS.capabilities).map(parseCapabilityDescriptor);
    const identities = new Set();
    for (const capability of capabilities) {
        if (identities.has(capability.id))
            reject('capabilities', 'duplicate capability ID');
        identities.add(capability.id);
    }
    capabilities.sort((left, right) => (left.id < right.id ? -1 : left.id > right.id ? 1 : 0));
    return {
        version: PROVIDER_DISCOVERY_VERSION,
        provider: identifier(raw['provider'], 'provider'),
        capabilities,
    };
}
/** Adapter authors pass their implemented inventory through the same boundary used by remote clients. */
export function createProviderDiscovery(provider, capabilities) {
    return parseProviderDiscovery({ version: PROVIDER_DISCOVERY_VERSION, provider, capabilities });
}
