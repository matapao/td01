export interface Block {
    /** How tools and references name it: "pieces". */
    readonly id: string;
    /** Its JSON file under data/, or a pattern for several ("data/maps/*.json"). */
    readonly file: string;
    /** Its JSON Schema (draft 2020-12). */
    readonly schema: string;
    readonly about: string;
    /** How-tos for agents: "Add a kit: copy one, change its parts and colours." */
    readonly how: readonly string[];
    /** Where its ids are, for references from other blocks: "/pieces/*\/id". */
    readonly ids: string | null;
}
export interface CodeEntry {
    /** A path or a pattern. */
    readonly path: string;
    readonly about: string;
    /** May agents propose changes to it (in the reviewed Code lane)? */
    readonly editable: boolean;
    readonly why: string;
    /** Its extension points, one line each: "award(car, points, label) gives a team points". */
    readonly hooks: readonly string[];
}
export interface BuildSection {
    /** The module esbuild starts from. */
    readonly entry: string;
    /** The page, copied as it is. */
    readonly html: string;
    /** Copied as they are: patterns. */
    readonly static: readonly string[];
    /** Left out of the bundle: /zirbel-net.js. */
    readonly external: readonly string[];
    /** Packages the host provides, by exact version: { "three": "0.180.0" }. */
    readonly provided: Readonly<Record<string, string>>;
    /** Other entry points, built beside the main one: authority, agent modules. Source path → output path. */
    readonly modules: Readonly<Record<string, string>>;
    /** Single files copied to another place in the bundle: public/style.css → style.css. */
    readonly moves: readonly {
        readonly from: string;
        readonly to: string;
    }[];
    /** Import prefixes the source uses for its own folders: "/shared/" → "shared/". */
    readonly aliases: Readonly<Record<string, string>>;
}
export interface BuildManifest {
    readonly about: string;
    readonly feel: readonly string[];
    readonly blocks: readonly Block[];
    readonly assets: string | null;
    readonly budgets: Readonly<Record<string, number>>;
    /** Source modules for agents: a picture of the data, the game's own data checks, the play adapter. */
    readonly look: string | null;
    readonly check: string | null;
    readonly play: string | null;
    /** When rooms apply a new data revision: at their next round, or at once. */
    readonly apply: 'round' | 'now';
    /** Who accepts code: the game's creator, or also the host's owner. */
    readonly review: 'creator' | 'owner';
    readonly build: BuildSection | null;
    readonly checks: {
        readonly types: string | null;
        readonly tests: string | null;
    };
    readonly code: readonly CodeEntry[];
}
export declare const BUILD_MANIFEST = "zirbel.build.json";
export declare const BLOCK_ID: RegExp;
export interface ManifestResult {
    readonly manifest: BuildManifest | null;
    readonly errors: readonly string[];
}
export declare function parseBuildManifest(input: unknown): ManifestResult;
/** The block a file belongs to, if any. */
export declare function blockOf(manifest: BuildManifest, path: string): Block | null;
/** Whether agents may propose a change to this file in the reviewed Code lane. The first entry that matches decides. */
export declare function codeEditable(manifest: BuildManifest, path: string): {
    editable: boolean;
    why: string;
};
/** Where a module named in the manifest is in an engine: its built form under agent/ (or as it is, if it is .js already). */
export declare function builtModule(source: string, kind: 'look' | 'check' | 'play'): string[];
