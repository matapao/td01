/** Provider AI policy. Every driver asks this same function, on every operation. */
export declare const AI_VERSION: 'zirbel.ai/session-v1';
export declare const AI_MODES: readonly ['guide', 'assist', 'play', 'build'];
export declare const AI_SURFACES: readonly ['api', 'browser', 'electron'];
export type AiMode = (typeof AI_MODES)[number];
export type AiSurface = (typeof AI_SURFACES)[number];
export interface AiPolicy {
    enabled: boolean;
    guide: boolean;
    assist: boolean;
    play: boolean;
    build: boolean;
    ui: boolean;
}
export declare function hostAiPolicy(s: {
    agentsPlay: boolean;
    agentsBuild: boolean;
    agentsGuide?: boolean;
    agentsAssist?: boolean;
    agentsUi?: boolean;
}): AiPolicy;
export interface AiScope {
    game: string;
    room: string;
    seat: number;
    mode: AiMode;
    surface: AiSurface;
}
/** Validate untrusted wire data before any driver allocates a device or session. */
export declare function aiScope(value: unknown): AiScope;
export interface AiSession extends AiScope {
    version: typeof AI_VERSION;
    id: string;
    pass: string;
    controller: string;
    expires: number;
    epoch: number;
    state: 'pairing' | 'active' | 'ended';
    label: string;
    seq: number;
}
export interface UiInput {
    keys?: string[];
    pointer?: {
        x: number;
        y: number;
        button?: 'left' | 'right';
    };
    for_ms: number;
}
/** The device input vocabulary is shared by discovery and the authoritative input decoder. */
export declare const UI_INPUT_SCHEMA: {
    type: string;
    additionalProperties: boolean;
    properties: {
        keys: {
            type: string;
            maxItems: number;
            items: {
                enum: string[];
            };
        };
        pointer: {
            type: string;
            additionalProperties: boolean;
            required: string[];
            properties: {
                x: {
                    type: string;
                    minimum: number;
                    maximum: number;
                };
                y: {
                    type: string;
                    minimum: number;
                    maximum: number;
                };
                button: {
                    enum: string[];
                };
            };
        };
        for_ms: {
            type: string;
            minimum: number;
            maximum: number;
            default: number;
        };
    };
};
export declare function aiLabel(mode: AiMode): string;
export declare function allowsAi(policy: AiPolicy, scope: AiScope, operation: 'pair' | 'observe' | 'input', now: number, session?: AiSession): boolean;
/** Closed input vocabulary: no script execution, text typing, browser shortcuts or arbitrary selectors. */
export declare function uiInput(value: unknown): UiInput;
