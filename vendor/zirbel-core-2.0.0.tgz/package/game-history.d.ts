export declare const GAME_HISTORY_FORMAT: 'zirbel.game-history/v1';
export declare const MAX_GAME_REVISIONS = 1000;
export declare const GAME_HISTORY_LIMITS: {
    readonly files: 2000;
    readonly bytes: number;
};
export declare const MAX_REVISION_BYTES: number;
export interface GameRevision {
    readonly id: string;
    readonly version: string;
    readonly title: string;
    readonly summary: string;
    readonly capturedAt: string;
    readonly entry: string;
    readonly artifact: string;
    readonly bytes: number;
    readonly source: {
        readonly commit: string;
        readonly dirty: boolean;
    } | null;
}
export interface GameHistory {
    readonly format: typeof GAME_HISTORY_FORMAT;
    readonly game: string;
    /** Capture order, oldest first. Each content identity occurs once. */
    readonly revisions: readonly GameRevision[];
}
/** Decode external JSON before rendering links or selecting a snapshot. */
export declare function readGameHistory(value: unknown, expectedGame?: string): GameHistory;
/** Append without mutating old records; recapturing the same bytes retains the first record. */
export declare function appendGameRevision(history: GameHistory, value: GameRevision): GameHistory;
/** The launch route contains validated identifiers, never a caller-selected URL. */
export declare function gameRevisionPath(game: string, id: string): string;
