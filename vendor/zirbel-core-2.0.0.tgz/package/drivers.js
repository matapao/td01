import { aiScope, aiLabel, AI_VERSION } from './ai.js';
export function freeSeat(seats, max = 253) {
    for (let id = 1; id <= max; id++)
        if (!seats[id])
            return id;
    return 0;
}
export function playerCount(members) {
    return members.reduce((n, m) => n + (m.local ? 0 : 1), 0);
}
/** The same pairing validation runs before Chrome or Electron attaches its debugger. */
export function readUiGrant(value, now = Date.now()) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        throw new Error('Invalid pairing grant');
    const v = value, raw = v['session'];
    const scope = aiScope(raw);
    const s = raw;
    const text = (value) => typeof value === 'string' && value.length > 0 && value.length <= 200;
    if (v['version'] !== AI_VERSION ||
        s['version'] !== AI_VERSION ||
        scope.surface === 'api' ||
        scope.mode === 'build' ||
        s['state'] !== 'pairing' ||
        s['epoch'] !== 1 ||
        s['seq'] !== 0 ||
        s['label'] !== aiLabel(scope.mode) ||
        !text(s['id']) ||
        !/^[\w-]{1,80}$/.test(s['id']) ||
        !text(s['pass']) ||
        !text(s['controller']) ||
        !text(v['token']) ||
        !/^[\w-]{1,100}$/.test(v['token']) ||
        typeof s['expires'] !== 'number' ||
        !Number.isFinite(s['expires']) ||
        s['expires'] <= now ||
        typeof v['pair_expires'] !== 'number' ||
        !Number.isFinite(v['pair_expires']) ||
        v['pair_expires'] <= now ||
        v['pair_expires'] > s['expires'] ||
        typeof v['origin'] !== 'string' ||
        typeof v['websocket'] !== 'string')
        throw new Error('Pairing expired or unsupported');
    const URLClass = globalThis.URL;
    const origin = new URLClass(v['origin']), endpoint = new URLClass(v['websocket']);
    if (!['http:', 'https:'].includes(origin.protocol) ||
        v['origin'] !== origin.origin ||
        endpoint.origin !== origin.origin.replace(/^http/, 'ws') ||
        endpoint.pathname !== '/_agent/ui' ||
        endpoint.username ||
        endpoint.password ||
        endpoint.search ||
        endpoint.hash)
        throw new Error('Pairing endpoint does not match the provider');
    return {
        version: AI_VERSION,
        origin: origin.origin,
        websocket: v['websocket'],
        token: v['token'],
        pair_expires: v['pair_expires'],
        session: {
            ...scope,
            version: AI_VERSION,
            id: s['id'],
            pass: s['pass'],
            controller: s['controller'],
            expires: s['expires'],
            epoch: 1,
            seq: 0,
            label: aiLabel(scope.mode),
            state: 'pairing',
        },
    };
}
