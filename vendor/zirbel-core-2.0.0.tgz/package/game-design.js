/** Decode bounded JSON data without losing non-finite values or accepting executable objects. */
export function readDesignData(input) {
    let remaining = 200_000;
    const active = new Set();
    function read(value, depth) {
        if (--remaining < 0 || depth > 32)
            throw new Error('Design data exceeds its value or depth budget');
        if (value === null || typeof value === 'string' || typeof value === 'boolean')
            return value;
        if (typeof value === 'number' && Number.isFinite(value))
            return value;
        if (!value || typeof value !== 'object')
            throw new Error('Design data must contain finite JSON values');
        if (active.has(value))
            throw new Error('Design data contains a cycle');
        active.add(value);
        let result;
        if (Array.isArray(value))
            result = value.map((child) => read(child, depth + 1));
        else {
            if (Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null)
                throw new Error('Design data must use plain JSON objects');
            result = Object.fromEntries(Object.entries(value).map(([key, child]) => [key, read(child, depth + 1)]));
        }
        active.delete(value);
        return result;
    }
    return read(input, 0);
}
/** Derive depth from parent links and refuse orphaned, cyclic or unbounded graphs. */
export function designDepths(nodes) {
    if (nodes.length > 1024)
        throw new Error('Design graphs allow at most 1024 nodes');
    const byId = new Map(nodes.map((node) => [node.id, node]));
    if (byId.size !== nodes.length)
        throw new Error('Duplicate design node id');
    const depths = new Map();
    for (const node of nodes) {
        const chain = [];
        let cursor = node.id;
        while (cursor !== null && !depths.has(cursor)) {
            if (chain.includes(cursor))
                throw new Error(`Design parent cycle at ${cursor}`);
            if (chain.length >= 32)
                throw new Error('Design nesting exceeds 32 levels');
            const next = byId.get(cursor);
            if (!next)
                throw new Error(`Unknown design parent ${cursor}`);
            chain.push(cursor);
            cursor = next.parent;
        }
        let depth = cursor === null ? -1 : (depths.get(cursor) ?? -1);
        for (const id of chain.reverse()) {
            depth++;
            if (depth >= 32)
                throw new Error('Design nesting exceeds 32 levels');
            depths.set(id, depth);
        }
    }
    return depths;
}
/** Semantic checks after decoding the published GameDefinition JSON Schema. No sources are fetched. */
export function validateDesignGraph(design) {
    const errors = [];
    const references = new Set();
    for (const ref of design.references) {
        if (references.has(ref.id))
            errors.push(`Duplicate design reference ${ref.id}`);
        references.add(ref.id);
    }
    const checkReferences = (ids, where) => {
        for (const id of ids)
            if (!references.has(id))
                errors.push(`${where}: unknown source reference ${id}`);
    };
    const blocks = new Map(design.blocks.map((block) => [block.id, block]));
    const ideas = new Map(design.ideas.map((idea) => [idea.id, idea]));
    for (const nodes of [design.blocks, design.ideas]) {
        try {
            designDepths(nodes);
        }
        catch (error) {
            errors.push(error instanceof Error ? error.message : 'Invalid design graph');
        }
    }
    const roots = design.blocks.filter((block) => block.parent === null);
    if (roots.length !== 1 || roots[0]?.id !== design.root)
        errors.push('Design needs one declared root building block');
    if (design.coverage === 'complete' && design.unknowns.length)
        errors.push('A complete design cannot contain unresolved unknowns');
    for (const block of design.blocks) {
        try {
            readDesignData(block.data);
        }
        catch (error) {
            errors.push(`${block.id}: ${error instanceof Error ? error.message : 'Invalid JSON data'}`);
        }
        checkReferences(block.sources, block.id);
        for (const id of block.ideas) {
            if (ideas.get(id)?.block !== block.id)
                errors.push(`${block.id}: idea ${id} does not belong to this block`);
        }
    }
    for (const idea of design.ideas) {
        if (!blocks.get(idea.block)?.ideas.includes(idea.id))
            errors.push(`Idea ${idea.id} has no matching building block`);
        checkReferences(idea.evidence.sources, idea.id);
        checkReferences(idea.implementation, idea.id);
        checkReferences(idea.verification.references, idea.id);
        if (idea.evidence.origin === 'authored' &&
            (!idea.evidence.author || !idea.evidence.recordedAt || !idea.evidence.sources.length)) {
            errors.push(`Authored idea ${idea.id} needs its author, recorded time and original source`);
        }
        if (idea.evidence.recordedAt !== null && !Number.isFinite(Date.parse(idea.evidence.recordedAt)))
            errors.push(`Idea ${idea.id} has an invalid recorded time`);
        if (idea.evidence.origin === 'inferred' && !idea.evidence.sources.length)
            errors.push(`Inferred idea ${idea.id} needs supporting sources`);
        if (idea.evidence.origin === 'unknown' &&
            (idea.evidence.author !== null || idea.evidence.recordedAt !== null)) {
            errors.push(`Unknown idea ${idea.id} cannot invent an author or historical time`);
        }
        if (idea.decision.alternatives.filter((alternative) => alternative.disposition === 'chosen').length > 1)
            errors.push(`Idea ${idea.id} has multiple chosen alternatives`);
        if ((idea.verification.status === 'passed' || idea.verification.status === 'failed') &&
            !idea.verification.references.length) {
            errors.push(`Verified idea ${idea.id} needs an actual result reference`);
        }
    }
    return errors;
}
/** A bounded view over one JSON document; refs let an agent request omitted source/details explicitly. */
export function designContext(design, focus, maxCharacters = 24_000) {
    if (!Number.isSafeInteger(maxCharacters) || maxCharacters < 2048 || maxCharacters > 128_000) {
        throw new Error('Design context budget must be 2048 to 128000 characters');
    }
    const depths = designDepths(design.blocks);
    designDepths(design.ideas);
    const byId = new Map(design.blocks.map((block) => [block.id, block]));
    const target = byId.get(focus);
    if (!target)
        throw new Error(`Unknown design focus ${focus}`);
    const candidates = [target];
    let parent = target.parent;
    while (parent !== null) {
        const block = byId.get(parent);
        if (!block)
            throw new Error(`Unknown design parent ${parent}`);
        candidates.push(block);
        parent = block.parent;
    }
    candidates.push(...design.blocks.filter((block) => block.parent === focus));
    const blocks = [];
    const ideas = [];
    const references = [];
    const omitted = { blocks: 0, ideas: 0, references: 0, data: 0 };
    const result = {
        format: 'zirbel-design-context/v1',
        focus,
        blocks,
        ideas,
        references,
        focusData: null,
        focusDataIncluded: false,
        omitted,
    };
    // Reserve space for omission counts without allowing their final digit changes to cross the bound.
    const fits = () => JSON.stringify(result).length <= maxCharacters - 128;
    const selected = [];
    for (const block of candidates) {
        const summary = block.summary.slice(0, 512);
        blocks.push({
            id: block.id,
            parent: block.parent,
            title: block.title,
            kind: block.kind,
            depth: depths.get(block.id) ?? 0,
            summary,
            excerpt: summary !== block.summary,
        });
        if (blocks.length > 32 || !fits()) {
            blocks.pop();
            omitted.blocks++;
        }
        else
            selected.push(block);
    }
    const allIdeas = new Map(design.ideas.map((idea) => [idea.id, idea]));
    const wantedIdeas = new Set(selected.flatMap((block) => [...block.ideas]));
    for (const id of wantedIdeas) {
        const idea = allIdeas.get(id);
        if (idea?.parent && !wantedIdeas.has(idea.parent))
            wantedIdeas.add(idea.parent);
        if (wantedIdeas.size > 1024)
            throw new Error('Design idea ancestry exceeds its graph budget');
    }
    const wantedReferences = new Set(selected.flatMap((block) => [...block.sources]));
    const relatedIdeas = [];
    for (const id of wantedIdeas) {
        const idea = allIdeas.get(id);
        if (!idea)
            throw new Error(`Unknown design idea ${id}`);
        for (const reference of [
            ...idea.evidence.sources,
            ...idea.implementation,
            ...idea.verification.references,
        ])
            wantedReferences.add(reference);
        relatedIdeas.push(idea);
    }
    const referenceById = new Map(design.references.map((reference) => [reference.id, reference]));
    for (const id of wantedReferences) {
        const reference = referenceById.get(id);
        if (!reference)
            throw new Error(`Unknown design source reference ${id}`);
        references.push(reference);
        if (references.length > 128 || !fits()) {
            references.pop();
            omitted.references++;
        }
    }
    for (const idea of relatedIdeas) {
        ideas.push(idea);
        if (ideas.length > 32 || !fits()) {
            ideas.pop();
            omitted.ideas++;
        }
    }
    result.focusData = target.data;
    result.focusDataIncluded = true;
    if (!fits()) {
        result.focusData = null;
        result.focusDataIncluded = false;
        omitted.data = 1;
    }
    return result;
}
