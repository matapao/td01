/** Provider AI policy. Every driver asks this same function, on every operation. */
export const AI_VERSION = 'zirbel.ai/session-v1';
export const AI_MODES = ['guide', 'assist', 'play', 'build'];
export const AI_SURFACES = ['api', 'browser', 'electron'];
export function hostAiPolicy(s) {
    return {
        enabled: s.agentsPlay || s.agentsBuild || s.agentsGuide === true || s.agentsAssist === true,
        play: s.agentsPlay,
        build: s.agentsBuild,
        guide: s.agentsGuide === true,
        assist: s.agentsAssist === true,
        ui: s.agentsUi === true,
    };
}
/** Validate untrusted wire data before any driver allocates a device or session. */
export function aiScope(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        throw new Error('Invalid AI scope');
    const v = value;
    if (typeof v['game'] !== 'string' ||
        !/^[a-z0-9][a-z0-9-]{1,31}$/.test(v['game']) ||
        typeof v['room'] !== 'string' ||
        !/^[A-Z0-9]{4,32}$/.test(v['room']) ||
        !Number.isInteger(v['seat']) ||
        v['seat'] < 1 ||
        v['seat'] > 253 ||
        !AI_MODES.includes(v['mode']) ||
        !AI_SURFACES.includes(v['surface']))
        throw new Error('Invalid AI scope');
    return {
        game: v['game'],
        room: v['room'],
        seat: v['seat'],
        mode: v['mode'],
        surface: v['surface'],
    };
}
const KEYS = new Set([
    'w',
    'a',
    's',
    'd',
    'q',
    'e',
    'r',
    'f',
    'c',
    'v',
    'x',
    'z',
    '1',
    '2',
    '3',
    '4',
    '5',
    '6',
    '7',
    '8',
    '9',
    '0',
    'ArrowUp',
    'ArrowDown',
    'ArrowLeft',
    'ArrowRight',
    'Space',
    'Shift',
    'Escape',
    'Enter',
]);
/** The device input vocabulary is shared by discovery and the authoritative input decoder. */
export const UI_INPUT_SCHEMA = {
    type: 'object',
    additionalProperties: false,
    properties: {
        keys: { type: 'array', maxItems: 6, items: { enum: [...KEYS] } },
        pointer: {
            type: 'object',
            additionalProperties: false,
            required: ['x', 'y'],
            properties: {
                x: { type: 'number', minimum: 0, maximum: 1 },
                y: { type: 'number', minimum: 0, maximum: 1 },
                button: { enum: ['left', 'right'] },
            },
        },
        for_ms: { type: 'integer', minimum: 1, maximum: 1000, default: 200 },
    },
};
export function aiLabel(mode) {
    return { guide: 'AI guide', assist: 'AI assisted', play: 'AI bot', build: 'AI build' }[mode];
}
export function allowsAi(policy, scope, operation, now, session) {
    if (!AI_MODES.includes(scope.mode) ||
        !AI_SURFACES.includes(scope.surface) ||
        policy.enabled !== true ||
        policy[scope.mode] !== true ||
        (scope.surface !== 'api' && !policy.ui))
        return false;
    if (session &&
        (session.state === 'ended' ||
            !Number.isFinite(session.expires) ||
            session.expires <= now ||
            (operation !== 'pair' && session.state !== 'active')))
        return false;
    if (operation === 'input' && (scope.mode === 'guide' || scope.mode === 'build'))
        return false;
    return true;
}
/** Closed input vocabulary: no script execution, text typing, browser shortcuts or arbitrary selectors. */
export function uiInput(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        throw new Error('Input must be an object');
    const v = value;
    if (Object.keys(v).some((k) => !['keys', 'pointer', 'for_ms'].includes(k)))
        throw new Error('Unknown input field');
    const hold = v['for_ms'] ?? 200;
    if (!Number.isInteger(hold) || hold < 1 || hold > 1000)
        throw new Error('for_ms must be 1..1000');
    const out = { for_ms: hold };
    if (v['keys'] !== undefined) {
        const keys = v['keys'];
        if (!Array.isArray(keys) || keys.length > 6 || keys.some((k) => typeof k !== 'string' || !KEYS.has(k)))
            throw new Error('Unsupported game key');
        out.keys = [...new Set(keys)];
    }
    if (v['pointer'] !== undefined) {
        const p = v['pointer'];
        if (!p ||
            typeof p !== 'object' ||
            Array.isArray(p) ||
            Object.keys(p).some((k) => !['x', 'y', 'button'].includes(k)) ||
            typeof p['x'] !== 'number' ||
            typeof p['y'] !== 'number' ||
            !Number.isFinite(p['x']) ||
            !Number.isFinite(p['y']) ||
            p['x'] < 0 ||
            p['x'] > 1 ||
            p['y'] < 0 ||
            p['y'] > 1 ||
            (p['button'] !== undefined && p['button'] !== 'left' && p['button'] !== 'right'))
            throw new Error('Pointer must be inside the game viewport');
        out.pointer = {
            x: p['x'],
            y: p['y'],
            ...(p['button'] ? { button: p['button'] } : {}),
        };
    }
    return out;
}
