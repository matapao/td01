/**
 * JSON Pointer (RFC 6901) and JSON Patch (RFC 6902): how agents change a block without sending all
 * of it. A patch applies as a whole or not at all, and the document it is given is never changed.
 */
const structuredClone = globalThis.structuredClone;
export class PatchError extends Error {
}
/** At most this many operations in one patch. */
export const MAX_OPS = 2000;
/** "/a/b~1c" → ["a", "b/c"]. Throws on a pointer that doesn't start with "/" (but "" is the whole document). */
export function parsePointer(pointer) {
    if (pointer === '')
        return [];
    if (!pointer.startsWith('/'))
        throw new PatchError(`"${pointer}" is not a JSON Pointer: it must start with /`);
    return pointer
        .slice(1)
        .split('/')
        .map((s) => {
        if (/~(?![01])/.test(s))
            throw new PatchError(`"${pointer}": ~ must be followed by 0 or 1`);
        return s.replace(/~1/g, '/').replace(/~0/g, '~');
    });
}
export function formatPointer(parts) {
    return parts.map((p) => '/' + String(p).replace(/~/g, '~0').replace(/\//g, '~1')).join('');
}
const isObject = (v) => typeof v === 'object' && v !== null && !Array.isArray(v);
/** What the pointer points at, or undefined. */
export function getPointer(doc, pointer) {
    let at = doc;
    for (const key of parsePointer(pointer)) {
        if (Array.isArray(at)) {
            const i = arrayIndex(key, at.length, false, pointer);
            at = at[i];
        }
        else if (isObject(at))
            at = Object.prototype.hasOwnProperty.call(at, key) ? at[key] : undefined;
        else
            return undefined;
        if (at === undefined)
            return undefined;
    }
    return at;
}
function arrayIndex(key, length, forAdd, pointer) {
    if (key === '-' && forAdd)
        return length;
    if (!/^(?:0|[1-9][0-9]*)$/.test(key))
        throw new PatchError(`${pointer}: "${key}" is not an array index`);
    const i = Number(key);
    if (i > length || (!forAdd && i === length))
        throw new PatchError(`${pointer}: index ${i} is past the end of the array (length ${length})`);
    return i;
}
/** RFC 6902 equality: same type and value; objects by their keys, arrays in order. */
export function jsonEqual(a, b) {
    if (a === b)
        return true;
    if (Array.isArray(a))
        return Array.isArray(b) && a.length === b.length && a.every((x, i) => jsonEqual(x, b[i]));
    if (isObject(a) && isObject(b)) {
        const ka = Object.keys(a), kb = Object.keys(b);
        return (ka.length === kb.length &&
            ka.every((k) => Object.prototype.hasOwnProperty.call(b, k) && jsonEqual(a[k], b[k])));
    }
    return false;
}
/** Checks that a value is a list of patch operations, and returns it typed. */
export function parsePatch(input) {
    if (!Array.isArray(input))
        throw new PatchError('a JSON Patch is a list of operations');
    if (input.length > MAX_OPS)
        throw new PatchError(`a patch has at most ${MAX_OPS} operations, not ${input.length}`);
    return input.map((raw, i) => {
        if (!isObject(raw))
            throw new PatchError(`operation ${i} is not an object`);
        const { op, path, value, from } = raw;
        if (typeof path !== 'string')
            throw new PatchError(`operation ${i} has no path`);
        parsePointer(path);
        switch (op) {
            case 'add':
            case 'replace':
            case 'test':
                if (value === undefined)
                    throw new PatchError(`operation ${i} (${op}) has no value`);
                return { op, path, value };
            case 'remove':
                return { op, path };
            case 'move':
            case 'copy':
                if (typeof from !== 'string')
                    throw new PatchError(`operation ${i} (${op}) has no from`);
                parsePointer(from);
                return { op, path, from };
            default:
                throw new PatchError(`operation ${i}: "${String(op)}" is not one of add, remove, replace, move, copy, test`);
        }
    });
}
/** The document with the patch applied. Throws PatchError (naming the operation) if any operation can't apply. */
export function applyPatch(doc, ops) {
    let root = structuredClone(doc);
    ops.forEach((o, i) => {
        try {
            root = applyOne(root, o);
        }
        catch (e) {
            if (e instanceof PatchError)
                throw new PatchError(`operation ${i} (${o.op} ${o.path}): ${e.message}`);
            throw e;
        }
    });
    return root;
}
function applyOne(root, o) {
    switch (o.op) {
        case 'add':
            return add(root, o.path, structuredClone(o.value));
        case 'remove':
            return remove(root, o.path).root;
        case 'replace': {
            if (o.path === '')
                return structuredClone(o.value);
            const { parent, key } = locate(root, o.path, false);
            if (Array.isArray(parent))
                parent[arrayIndex(key, parent.length, false, o.path)] = structuredClone(o.value);
            else {
                if (!Object.prototype.hasOwnProperty.call(parent, key))
                    throw new PatchError('there is nothing there to replace');
                parent[key] = structuredClone(o.value);
            }
            return root;
        }
        case 'test': {
            const v = getPointer(root, o.path);
            if (v === undefined)
                throw new PatchError('there is nothing there');
            if (!jsonEqual(v, o.value))
                throw new PatchError(`the value there is ${short(v)}, not ${short(o.value)}`);
            return root;
        }
        case 'move': {
            if (o.path === o.from)
                return root;
            if (o.path.startsWith(o.from + '/'))
                throw new PatchError("a value can't move into itself");
            const { root: r, value } = remove(root, o.from);
            return add(r, o.path, value);
        }
        case 'copy': {
            const v = getPointer(root, o.from);
            if (v === undefined)
                throw new PatchError(`there is nothing at ${o.from} to copy`);
            return add(root, o.path, structuredClone(v));
        }
    }
}
function locate(root, pointer, forAdd) {
    const parts = parsePointer(pointer);
    const key = parts.pop();
    if (key === undefined)
        throw new PatchError('the whole document has no parent');
    let at = root;
    for (const p of parts) {
        let next;
        if (Array.isArray(at))
            next = at[arrayIndex(p, at.length, false, pointer)];
        else if (isObject(at))
            next = Object.prototype.hasOwnProperty.call(at, p) ? at[p] : undefined;
        if (next === undefined || next === null || typeof next !== 'object')
            throw new PatchError(`its parent ${formatPointer(parts)} doesn't exist`);
        at = next;
    }
    if (!Array.isArray(at) && !isObject(at))
        throw new PatchError('its parent is not an object or array');
    if (Array.isArray(at) && !forAdd)
        arrayIndex(key, at.length, false, pointer);
    return { parent: at, key };
}
function add(root, pointer, value) {
    if (pointer === '')
        return value;
    const { parent, key } = locate(root, pointer, true);
    if (Array.isArray(parent))
        parent.splice(arrayIndex(key, parent.length, true, pointer), 0, value);
    else {
        if (key === '__proto__')
            throw new PatchError('"__proto__" is not a key a block can have');
        parent[key] = value;
    }
    return root;
}
function remove(root, pointer) {
    if (pointer === '')
        throw new PatchError("the whole document can't be removed");
    const { parent, key } = locate(root, pointer, false);
    if (Array.isArray(parent)) {
        const [value] = parent.splice(arrayIndex(key, parent.length, false, pointer), 1);
        return { root, value: value };
    }
    if (!Object.prototype.hasOwnProperty.call(parent, key))
        throw new PatchError('there is nothing there to remove');
    const value = parent[key];
    delete parent[key];
    return { root, value };
}
function short(v) {
    const s = JSON.stringify(v) ?? String(v);
    return s.length > 60 ? s.slice(0, 57) + '…' : s;
}
/** How a JSON text laid out its objects and arrays, read without building the value. */
function layoutOf(text) {
    const single = new Map();
    const stack = [];
    let line = 0, padObject = null, padArray = null, colon = null, comma = null;
    for (let i = 0; i < text.length; i++) {
        const c = text[i];
        if (c === '\n')
            line++;
        else if (c === '"') {
            let j = i + 1;
            while (j < text.length && text[j] !== '"')
                j += text[j] === '\\' ? 2 : 1;
            const top = stack[stack.length - 1];
            if (top && !top.array && top.wantKey) {
                try {
                    top.key = JSON.parse(text.slice(i, j + 1));
                }
                catch {
                    top.key = '';
                }
                top.wantKey = false;
            }
            i = j;
        }
        else if (c === '{' || c === '[') {
            const top = stack[stack.length - 1];
            const pointer = !top
                ? ''
                : top.pointer + '/' + (top.array ? String(top.index) : escapeKey(top.key ?? ''));
            stack.push({ pointer, line, array: c === '[', index: 0, key: null, wantKey: c === '{' });
            if (text[i + 1] !== '\n' && text[i + 1] !== '\r' && text[i + 1] !== (c === '{' ? '}' : ']')) {
                if (c === '{' && padObject === null)
                    padObject = text[i + 1] === ' ';
                if (c === '[' && padArray === null)
                    padArray = text[i + 1] === ' ';
            }
        }
        else if (c === '}' || c === ']') {
            const f = stack.pop();
            if (f)
                single.set(f.pointer, f.line === line);
        }
        else if (c === ',') {
            const top = stack[stack.length - 1];
            if (top?.array)
                top.index++;
            else if (top)
                top.wantKey = true;
            if (comma === null && text[i + 1] !== '\n' && text[i + 1] !== '\r')
                comma = text[i + 1] === ' ' ? ', ' : ',';
        }
        else if (c === ':' && colon === null)
            colon = text[i + 1] === ' ' ? ': ' : ':';
    }
    const m = /^[[{][ \t]*\r?\n([ \t]+)\S/.exec(text);
    // A file with only one kind of one-line container: the other is spaced the same.
    const either = padObject ?? padArray ?? true;
    return {
        single,
        padObject: padObject ?? either,
        padArray: padArray ?? either,
        colon: colon ?? ': ',
        comma: comma ?? ', ',
        indent: m ? m[1] : '  ',
        newline: text.includes('\r\n') ? '\r\n' : '\n',
    };
}
const escapeKey = (key) => key.replace(/~/g, '~0').replace(/\//g, '~1');
/**
 * The JSON text for a changed block, written the way the file was: each object and array on one
 * line or over several as it was before (new ones like their neighbours), the same indentation
 * and spacing, the same final newline. A diff then shows what changed and nothing else.
 */
export function formatLike(original, value) {
    const L = layoutOf(original);
    const nl = L.newline;
    const guess = (v, pointer, depth) => {
        const known = L.single.get(pointer);
        if (known !== undefined)
            return known;
        // A new item is laid out like the array's other items; a new member like its parent's other members.
        const parent = pointer.slice(0, pointer.lastIndexOf('/'));
        for (const [p, s] of L.single)
            if (p.startsWith(parent + '/') && p.lastIndexOf('/') === parent.length)
                return s;
        return depth >= 2 && JSON.stringify(v).length <= 72;
    };
    const write = (v, pointer, depth) => {
        if (v === null || typeof v !== 'object')
            return JSON.stringify(v);
        const entries = Array.isArray(v) ? v.map((x, i) => [String(i), x]) : Object.entries(v);
        const [open, close] = Array.isArray(v) ? ['[', ']'] : ['{', '}'];
        if (!entries.length)
            return open + close;
        const item = ([k, x]) => (Array.isArray(v) ? '' : JSON.stringify(k) + L.colon) +
            write(x, `${pointer}/${escapeKey(k)}`, depth + 1);
        if (guess(v, pointer, depth)) {
            const inner = entries.map(item).join(L.comma);
            return (Array.isArray(v) ? L.padArray : L.padObject)
                ? `${open} ${inner} ${close}`
                : open + inner + close;
        }
        const pre = nl + L.indent.repeat(depth + 1);
        return open + pre + entries.map(item).join(',' + pre) + nl + L.indent.repeat(depth) + close;
    };
    const text = write(value, '', 0);
    return /\r?\n$/.test(original) || original === '' ? text + nl : text;
}
/**
 * A JSON Patch from a to b: what changed, by place. Array items are changed in place where they
 * kept their index, added and removed where the array grew or shrank, and guarded with "test" so
 * the patch applied onto a document where items moved fails instead of changing the wrong one.
 */
export function diffJson(a, b, pointer = '') {
    if (jsonEqual(a, b))
        return [];
    if (isObject(a) && isObject(b)) {
        const ops = [];
        for (const k of Object.keys(a)) {
            if (Object.prototype.hasOwnProperty.call(b, k))
                continue;
            const p = `${pointer}/${escapeKey(k)}`;
            ops.push({ op: 'test', path: p, value: a[k] }, { op: 'remove', path: p });
        }
        for (const [k, v] of Object.entries(b)) {
            const p = `${pointer}/${escapeKey(k)}`;
            if (!Object.prototype.hasOwnProperty.call(a, k))
                ops.push({ op: 'add', path: p, value: v });
            else
                ops.push(...diffJson(a[k], v, p));
        }
        return ops;
    }
    if (Array.isArray(a) && Array.isArray(b)) {
        let pre = 0;
        while (pre < a.length && pre < b.length && jsonEqual(a[pre], b[pre]))
            pre++;
        let post = 0;
        while (post < a.length - pre &&
            post < b.length - pre &&
            jsonEqual(a[a.length - 1 - post], b[b.length - 1 - post]))
            post++;
        // The tests come first, against the document as it was, then the changes.
        const tests = [], ops = [];
        const guard = (i) => {
            if (i >= 0 && i < a.length && !tests.some((t) => t.path === `${pointer}/${i}`))
                tests.push({ op: 'test', path: `${pointer}/${i}`, value: a[i] });
        };
        const am = a.length - pre - post, bm = b.length - pre - post;
        // The changed middle: items changed in place, then the rest removed or added.
        const same = Math.min(am, bm);
        for (let i = 0; i < same; i++) {
            guard(pre + i);
            ops.push(...diffJson(a[pre + i], b[pre + i], `${pointer}/${pre + i}`));
        }
        for (let i = am - 1; i >= same; i--) {
            guard(pre + i);
            ops.push({ op: 'remove', path: `${pointer}/${pre + i}` });
        }
        if (bm > same && post > 0) {
            // Inserted between items: both neighbours must still be where they were. Appending needs no guard.
            guard(pre - 1);
            guard(a.length - post);
        }
        for (let i = same; i < bm; i++)
            ops.push({
                op: 'add',
                path: post === 0 ? `${pointer}/-` : `${pointer}/${pre + i}`,
                value: b[pre + i],
            });
        return [...tests, ...ops];
    }
    // A value replaced: only if it is still what it was, so a change made meanwhile isn't lost.
    return [
        { op: 'test', path: pointer, value: a },
        { op: 'replace', path: pointer, value: b },
    ];
}
