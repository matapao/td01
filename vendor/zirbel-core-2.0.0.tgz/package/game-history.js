/** Immutable playable alpha snapshots. Git provenance describes source; it is never the artifact identity. */
import { GAME_ID, GAME_VERSION, isBundlePath } from './game-manifest.js';
export const GAME_HISTORY_FORMAT = 'zirbel.game-history/v1';
export const MAX_GAME_REVISIONS = 1000;
export const GAME_HISTORY_LIMITS = { files: 2000, bytes: 128 * 1024 * 1024 };
export const MAX_REVISION_BYTES = 136 * 1024 * 1024;
const HASH = /^[a-f0-9]{64}$/;
const HIDDEN = /[\p{Cc}\p{Cf}\p{Co}\p{Cs}\p{Zl}\p{Zp}]/u;
function record(value, keys) {
    if (!value || typeof value !== 'object' || Array.isArray(value))
        throw new Error('Invalid game history');
    const out = value;
    if (Object.keys(out).some((key) => !keys.includes(key)))
        throw new Error('Unknown game history field');
    return out;
}
function text(value, max) {
    return (typeof value === 'string' &&
        value.length > 0 &&
        value.length <= max &&
        value.trim() === value &&
        !HIDDEN.test(value));
}
function revision(value) {
    const v = record(value, [
        'id',
        'version',
        'title',
        'summary',
        'capturedAt',
        'entry',
        'artifact',
        'bytes',
        'source',
    ]);
    const id = v['id'], version = v['version'], title = v['title'], summary = v['summary'];
    const capturedAt = v['capturedAt'], entry = v['entry'], artifact = v['artifact'], bytes = v['bytes'];
    if (typeof id !== 'string' ||
        !HASH.test(id) ||
        typeof version !== 'string' ||
        !GAME_VERSION.test(version) ||
        !text(title, 100) ||
        !text(summary, 500) ||
        typeof capturedAt !== 'string' ||
        !/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(capturedAt) ||
        !Number.isFinite(Date.parse(capturedAt)) ||
        new Date(capturedAt).toISOString() !== capturedAt ||
        !isBundlePath(entry) ||
        !/\.html?$/.test(entry) ||
        /[?#:%]/.test(entry) ||
        artifact !== `revisions/${id}.tgz` ||
        typeof bytes !== 'number' ||
        !Number.isSafeInteger(bytes) ||
        bytes < 1 ||
        bytes > MAX_REVISION_BYTES)
        throw new Error('Invalid playable game revision');
    let source = null;
    if (v['source'] !== null) {
        const s = record(v['source'], ['commit', 'dirty']);
        if (typeof s['commit'] !== 'string' ||
            !/^(?:[a-f0-9]{40}|[a-f0-9]{64})$/.test(s['commit']) ||
            typeof s['dirty'] !== 'boolean')
            throw new Error('Invalid game revision source');
        source = { commit: s['commit'], dirty: s['dirty'] };
    }
    return { id, version, title, summary, capturedAt, entry, artifact, bytes, source };
}
/** Decode external JSON before rendering links or selecting a snapshot. */
export function readGameHistory(value, expectedGame) {
    const v = record(value, ['format', 'game', 'revisions']);
    const game = v['game'], list = v['revisions'];
    if (v['format'] !== GAME_HISTORY_FORMAT ||
        typeof game !== 'string' ||
        !GAME_ID.test(game) ||
        (expectedGame !== undefined && game !== expectedGame) ||
        !Array.isArray(list) ||
        list.length > MAX_GAME_REVISIONS)
        throw new Error('Unsupported or mismatched game history');
    const revisions = list.map(revision);
    const ids = new Set();
    let previous = '';
    for (const item of revisions) {
        if (ids.has(item.id) || item.capturedAt < previous)
            throw new Error('Duplicate or unordered game revision');
        ids.add(item.id);
        previous = item.capturedAt;
    }
    return { format: GAME_HISTORY_FORMAT, game, revisions };
}
/** Append without mutating old records; recapturing the same bytes retains the first record. */
export function appendGameRevision(history, value) {
    const current = readGameHistory(history);
    const next = revision(value);
    const existing = current.revisions.find((item) => item.id === next.id);
    if (existing) {
        if (existing.bytes !== next.bytes || existing.entry !== next.entry || existing.version !== next.version)
            throw new Error('Game revision identity conflicts with its artifact');
        return current;
    }
    return readGameHistory({ ...current, revisions: [...current.revisions, next] });
}
/** The launch route contains validated identifiers, never a caller-selected URL. */
export function gameRevisionPath(game, id) {
    if (!GAME_ID.test(game) || !HASH.test(id))
        throw new Error('Invalid game revision route');
    return `/${game}/revisions/${id}/`;
}
