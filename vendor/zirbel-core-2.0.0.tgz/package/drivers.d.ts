import type { AiScope, AiSession, UiInput } from './ai.ts';
export interface UiObservation {
    image: {
        mime: 'image/jpeg' | 'image/png';
        data: string;
        width: number;
        height: number;
    };
    captured_at: number;
}
export interface AiDeviceDriver {
    context(scope: AiScope): Promise<{
        proof: string;
    }>;
    observe(): Promise<UiObservation>;
    input(input: UiInput): Promise<void>;
    release(): Promise<void>;
    close(): Promise<void>;
}
export interface UiGrant {
    version: 'zirbel.ai/session-v1';
    session: AiSession;
    websocket: string;
    origin: string;
    token: string;
    pair_expires: number;
}
export interface UiCommand {
    id: number;
    op: 'observe' | 'input';
    epoch: number;
    based_on?: number;
    input?: UiInput;
}
/** What room logic needs from a connection. Node/WebSocket fields belong to its driver. */
export interface Delivery {
    pending: number;
    inHeld: number;
    lastRx: number;
    closed: boolean;
    sendBytes(bytes: Uint8Array): boolean;
    fail(code: number): void;
    destroy(): void;
}
export declare function freeSeat(seats: readonly unknown[], max?: number): number;
export declare function playerCount(members: readonly {
    local: boolean;
}[]): number;
/** The same pairing validation runs before Chrome or Electron attaches its debugger. */
export declare function readUiGrant(value: unknown, now?: number): UiGrant;
