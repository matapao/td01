/** Declarative design context: nested building blocks, explicit decisions and their evidence. */
import type { Json } from './patch.ts';
export interface DesignReference {
    readonly id: string;
    readonly uri: string;
    readonly provider: string;
    readonly capabilities: readonly ('read' | 'write' | 'execute')[];
    readonly sha256?: string;
    readonly bytes?: number;
}
export interface DesignBlock {
    readonly id: string;
    readonly parent: string | null;
    readonly kind: 'game' | 'system' | 'data' | 'schema' | 'presentation' | 'story' | 'mechanic' | 'phase' | 'asset' | 'code' | 'document' | 'drawing';
    readonly title: string;
    readonly summary: string;
    readonly data: Json;
    readonly sources: readonly string[];
    readonly ideas: readonly string[];
}
export interface IdeaMoment {
    readonly id: string;
    readonly parent: string | null;
    readonly block: string;
    readonly title: string;
    readonly context: {
        readonly situation: string;
        readonly constraints: readonly string[];
    };
    readonly decision: {
        readonly choice: string;
        readonly rationale: string | null;
        readonly alternatives: readonly {
            readonly choice: string;
            readonly disposition: 'chosen' | 'rejected' | 'unresolved';
            readonly rationale: string | null;
        }[];
    };
    readonly evidence: {
        readonly origin: 'authored' | 'inferred' | 'unknown';
        readonly author: string | null;
        readonly recordedAt: string | null;
        readonly sources: readonly string[];
        readonly note: string;
    };
    readonly implementation: readonly string[];
    readonly verification: {
        readonly status: 'not-run' | 'unknown' | 'passed' | 'failed';
        readonly references: readonly string[];
        readonly note: string;
    };
}
export interface GameDesign {
    readonly format: 'zirbel-design/v1';
    readonly root: string;
    readonly summary: string;
    readonly storage: 'json-and-references';
    readonly coverage: 'partial' | 'complete';
    readonly capture: {
        readonly json: 'embedded' | 'partial' | 'none';
        readonly text: 'embedded' | 'partial' | 'none';
        readonly binaries: 'references' | 'none';
        readonly selfContainedRuntime: false;
    };
    readonly unknowns: readonly string[];
    readonly blocks: readonly DesignBlock[];
    readonly ideas: readonly IdeaMoment[];
    readonly references: readonly DesignReference[];
}
/** Decode bounded JSON data without losing non-finite values or accepting executable objects. */
export declare function readDesignData(input: unknown): Json;
/** Derive depth from parent links and refuse orphaned, cyclic or unbounded graphs. */
export declare function designDepths(nodes: readonly {
    readonly id: string;
    readonly parent: string | null;
}[]): Map<string, number>;
/** Semantic checks after decoding the published GameDefinition JSON Schema. No sources are fetched. */
export declare function validateDesignGraph(design: GameDesign): string[];
export interface DesignContext {
    readonly format: 'zirbel-design-context/v1';
    readonly focus: string;
    readonly blocks: readonly {
        readonly id: string;
        readonly parent: string | null;
        readonly title: string;
        readonly kind: DesignBlock['kind'];
        readonly depth: number;
        readonly summary: string;
        readonly excerpt: boolean;
    }[];
    readonly ideas: readonly IdeaMoment[];
    readonly references: readonly DesignReference[];
    readonly focusData: Json;
    readonly focusDataIncluded: boolean;
    readonly omitted: {
        readonly blocks: number;
        readonly ideas: number;
        readonly references: number;
        readonly data: number;
    };
}
/** A bounded view over one JSON document; refs let an agent request omitted source/details explicitly. */
export declare function designContext(design: GameDesign, focus: string, maxCharacters?: number): DesignContext;
