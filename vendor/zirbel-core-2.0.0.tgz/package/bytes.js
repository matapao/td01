/** Environment-neutral encodings used in contracts and content hashes. */
const environment = globalThis;
export const utf8 = (s) => new environment.TextEncoder().encode(s);
export function base64url(bytes) {
    const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';
    let out = '', bits = 0, value = 0;
    for (const byte of bytes) {
        value = (value << 8) | byte;
        bits += 8;
        while (bits >= 6) {
            bits -= 6;
            out += alphabet[(value >>> bits) & 63];
        }
    }
    if (bits)
        out += alphabet[(value << (6 - bits)) & 63];
    return out;
}
