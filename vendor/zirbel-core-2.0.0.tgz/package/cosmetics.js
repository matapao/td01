/** Portable visual-use contract. Games own all gameplay rules and statistics. */
export const COSMETIC_KINDS = ['model/gltf-binary', 'image/png', 'image/webp'];
export function isCosmeticKind(value) {
    return typeof value === 'string' && COSMETIC_KINDS.some((kind) => kind === value);
}
