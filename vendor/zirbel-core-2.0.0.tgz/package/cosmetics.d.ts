/** Portable visual-use contract. Games own all gameplay rules and statistics. */
export declare const COSMETIC_KINDS: readonly ['model/gltf-binary', 'image/png', 'image/webp'];
export type CosmeticKind = (typeof COSMETIC_KINDS)[number];
export declare function isCosmeticKind(value: unknown): value is CosmeticKind;
export interface CosmeticCompatibility {
    readonly approval: string;
    readonly loot: string;
    readonly game: string;
    readonly slot: string;
    readonly director: string;
}
export interface CosmeticFile {
    readonly sha256: string;
    readonly bytes: number;
    readonly type: CosmeticKind;
    readonly path?: string;
}
/** Content identity travels; damage, speed, rarity effects and other game rules never do. */
export interface CosmeticGraphics {
    readonly format: 'zirbel-cosmetic/v1';
    readonly item: string;
    readonly edition: string;
    readonly serial: number;
    readonly loot: string;
    /** Acquisition provenance, never a restriction on the target game. */
    readonly acquiredIn: string;
    readonly game: string;
    readonly slot: string;
    readonly kind: CosmeticKind;
    readonly files: readonly CosmeticFile[];
    readonly credit: {
        readonly artist: string;
        readonly name: string;
        readonly title: string;
        readonly attribution: string;
        /** Null means no licence was supplied; never invent a licence. */
        readonly licence: unknown;
        readonly sources: readonly {
            readonly url: string;
            readonly host: string;
        }[];
    };
}
