import { type AiPolicy, type AiScope, type AiSession } from './ai.ts';
export interface SessionDrivers {
    now(): number;
    random(): string;
    hash(value: string): string;
}
/** Session transitions are reusable logic. A driver authenticates passes and proves seat ownership before pair(). */
export declare class AiSessions {
    private readonly records;
    private readonly drivers;
    constructor(drivers: SessionDrivers);
    issue(scope: AiScope, pass: {
        id: string;
        expires: number;
    }, controller: string, policy: AiPolicy): {
        session: AiSession;
        token: string;
        pair_expires: number;
    };
    get(id: string): AiSession | null;
    pair(id: string, token: string, scope: Pick<AiScope, 'game' | 'room' | 'seat'>, policy: AiPolicy): AiSession;
    authorize(id: string, policy: AiPolicy, operation: 'observe' | 'input', epoch: number): AiSession;
    observed(id: string): number;
    end(id: string): void;
    revoke(pass: string): void;
    list(game: string, room: string): AiSession[];
    private sweep;
}
